//go:build !windows

// Package appwin opens a local web page as a program window (ixcast and
// godrawr): Chrome, Chromium or Edge in app mode, else the default browser.
package appwin

import (
	"fmt"
	"os/exec"
	"runtime"
)

// Open shows url as an app window: Chrome, Chromium or Edge with no
// address bar or tabs, else the default browser.  profile (a folder) keeps
// the window's own settings; "" uses the browser's.
func Open(url, profile string, w, h int) {
	args := []string{"--app=" + url, fmt.Sprintf("--window-size=%d,%d", w, h), "--no-first-run"}
	if profile != "" {
		args = append(args, "--user-data-dir="+profile)
	}
	for _, b := range []string{"google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "microsoft-edge", "microsoft-edge-stable"} {
		if p, err := exec.LookPath(b); err == nil {
			if exec.Command(p, args...).Start() == nil {
				return
			}
		}
	}
	if runtime.GOOS == "darwin" {
		exec.Command("open", url).Start()
		return
	}
	exec.Command("xdg-open", url).Start()
}
