// Package appwin opens a local web page as a program window (ixcast and
// godrawr): Edge or Chrome in app mode, else the default browser.
package appwin

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"syscall"
)

// Open shows url as an app window: Edge or Chrome with no address bar or
// tabs, else the default browser.  profile (a folder) keeps the window's
// own settings; "" uses the browser's.
func Open(url, profile string, w, h int) {
	var tries []string
	for _, env := range []string{"ProgramFiles(x86)", "ProgramFiles", "LocalAppData"} {
		base := os.Getenv(env)
		if base == "" {
			continue
		}
		tries = append(tries, filepath.Join(base, `Microsoft\Edge\Application\msedge.exe`), filepath.Join(base, `Google\Chrome\Application\chrome.exe`))
	}
	for _, b := range tries {
		if _, err := os.Stat(b); err != nil {
			continue
		}
		args := []string{"--app=" + url, fmt.Sprintf("--window-size=%d,%d", w, h), "--autoplay-policy=no-user-gesture-required", "--no-first-run"}
		if profile != "" {
			args = append(args, "--user-data-dir="+profile)
		}
		if exec.Command(b, args...).Start() == nil {
			return
		}
	}
	cmd := exec.Command("rundll32", "url.dll,FileProtocolHandler", url)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	cmd.Start()
}
