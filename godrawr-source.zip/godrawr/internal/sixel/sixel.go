// Package sixel turns pictures (GIF, PNG, JPEG) into DEC sixel graphics,
// which terminals such as SyncTERM draw on the screen.
package sixel

import (
	"bytes"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"image/gif"
	"image/jpeg"
	"image/png"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
)

// Exts are the picture files sixel can show: ready-made sixel files and
// the pictures it converts.
var Exts = []string{".six", ".sixel", ".png", ".gif", ".jpg", ".jpeg"}

// IsPicture reports whether a file name is a picture sixel can show.
func IsPicture(name string) bool {
	e := strings.ToLower(filepath.Ext(name))
	for _, x := range Exts {
		if e == x {
			return true
		}
	}
	return false
}

// IsSixelFile reports whether name is a ready-made sixel file (.six, .sixel).
func IsSixelFile(name string) bool {
	e := strings.ToLower(filepath.Ext(name))
	return e == ".six" || e == ".sixel"
}

// Decode reads a GIF (first frame), PNG or JPEG.
func Decode(r io.Reader) (image.Image, error) {
	b, err := io.ReadAll(io.LimitReader(r, 64<<20))
	if err != nil {
		return nil, err
	}
	switch {
	case bytes.HasPrefix(b, []byte("GIF8")):
		return gif.Decode(bytes.NewReader(b))
	case bytes.HasPrefix(b, []byte("\x89PNG")):
		return png.Decode(bytes.NewReader(b))
	case bytes.HasPrefix(b, []byte{0xff, 0xd8}):
		return jpeg.Decode(bytes.NewReader(b))
	}
	img, _, err := image.Decode(bytes.NewReader(b))
	return img, err
}

// Scale shrinks img to fit maxW x maxH (keeping its shape; pictures that
// fit already are left as they are), averaging the pixels it merges.
func Scale(img image.Image, maxW, maxH int) image.Image {
	b := img.Bounds()
	w, h := b.Dx(), b.Dy()
	if w <= 0 || h <= 0 || (w <= maxW && h <= maxH) || maxW <= 0 || maxH <= 0 {
		return img
	}
	f := min(float64(maxW)/float64(w), float64(maxH)/float64(h))
	nw, nh := max(1, int(float64(w)*f)), max(1, int(float64(h)*f))
	out := image.NewRGBA(image.Rect(0, 0, nw, nh))
	for y := 0; y < nh; y++ {
		y0, y1 := b.Min.Y+y*h/nh, b.Min.Y+(y+1)*h/nh
		if y1 <= y0 {
			y1 = y0 + 1
		}
		for x := 0; x < nw; x++ {
			x0, x1 := b.Min.X+x*w/nw, b.Min.X+(x+1)*w/nw
			if x1 <= x0 {
				x1 = x0 + 1
			}
			var r, g, bl, a, n uint64
			for yy := y0; yy < y1; yy++ {
				for xx := x0; xx < x1; xx++ {
					cr, cg, cb, ca := img.At(xx, yy).RGBA()
					r, g, bl, a, n = r+uint64(cr), g+uint64(cg), bl+uint64(cb), a+uint64(ca), n+1
				}
			}
			out.SetRGBA(x, y, color.RGBA{uint8(r / n >> 8), uint8(g / n >> 8), uint8(bl / n >> 8), uint8(a / n >> 8)})
		}
	}
	return out
}

// Quantize gives img a palette of at most n colours (median cut), with
// Floyd-Steinberg dithering.  Pictures that already have a small enough
// palette keep it.
func Quantize(img image.Image, n int) *image.Paletted {
	if p, ok := img.(*image.Paletted); ok && len(p.Palette) <= n {
		return p
	}
	b := img.Bounds()
	// sample the colours (every pixel of a picture this size is fine)
	var px [][3]uint8
	step := max(1, b.Dx()*b.Dy()/200000)
	k := 0
	for y := b.Min.Y; y < b.Max.Y; y++ {
		for x := b.Min.X; x < b.Max.X; x++ {
			if k%step == 0 {
				r, g, bl, _ := img.At(x, y).RGBA()
				px = append(px, [3]uint8{uint8(r >> 8), uint8(g >> 8), uint8(bl >> 8)})
			}
			k++
		}
	}
	pal := medianCut(px, n)
	out := image.NewPaletted(image.Rect(0, 0, b.Dx(), b.Dy()), pal)
	draw.FloydSteinberg.Draw(out, out.Bounds(), img, b.Min)
	return out
}

// medianCut splits the colours into up to n boxes and takes their means.
func medianCut(px [][3]uint8, n int) color.Palette {
	if len(px) == 0 {
		return color.Palette{color.Black}
	}
	boxes := [][][3]uint8{px}
	for len(boxes) < n {
		// split the box with the widest channel range
		bi, bc, br := -1, 0, -1
		for i, bx := range boxes {
			if len(bx) < 2 {
				continue
			}
			for c := 0; c < 3; c++ {
				lo, hi := 255, 0
				for _, p := range bx {
					lo, hi = min(lo, int(p[c])), max(hi, int(p[c]))
				}
				if hi-lo > br {
					bi, bc, br = i, c, hi-lo
				}
			}
		}
		if bi < 0 || br == 0 {
			break
		}
		bx := boxes[bi]
		sort.Slice(bx, func(i, j int) bool { return bx[i][bc] < bx[j][bc] })
		m := len(bx) / 2
		boxes[bi] = bx[:m]
		boxes = append(boxes, bx[m:])
	}
	var pal color.Palette
	for _, bx := range boxes {
		var r, g, b int
		for _, p := range bx {
			r, g, b = r+int(p[0]), g+int(p[1]), b+int(p[2])
		}
		l := max(1, len(bx))
		pal = append(pal, color.RGBA{uint8(r / l), uint8(g / l), uint8(b / l), 255})
	}
	return pal
}

// Encode writes img as sixel: a DCS string the terminal draws at the
// cursor (up to 256 colours).
func Encode(w io.Writer, img image.Image) error {
	p := Quantize(img, 256)
	bw := &bytes.Buffer{}
	W, H := p.Bounds().Dx(), p.Bounds().Dy()
	bw.WriteString("\x1bP0;1;0q")
	fmt.Fprintf(bw, "\"1;1;%d;%d", W, H)
	// transparent pixels are left as the screen has them
	transparent := -1
	for i, c := range p.Palette {
		r, g, b, a := c.RGBA()
		if a < 0x8000 {
			if transparent < 0 {
				transparent = i
			}
			continue
		}
		fmt.Fprintf(bw, "#%d;2;%d;%d;%d", i, int(r>>8)*100/255, int(g>>8)*100/255, int(b>>8)*100/255)
	}
	row := make([]byte, W)
	for y0 := 0; y0 < H; y0 += 6 {
		// the colours used in this band of six rows
		used := map[int]bool{}
		for dy := 0; dy < 6 && y0+dy < H; dy++ {
			off := (y0 + dy) * p.Stride
			for x := 0; x < W; x++ {
				used[int(p.Pix[off+x])] = true
			}
		}
		cols := make([]int, 0, len(used))
		for c := range used {
			if c != transparent {
				cols = append(cols, c)
			}
		}
		sort.Ints(cols)
		for ci, c := range cols {
			last := -1
			for x := 0; x < W; x++ {
				var bits byte
				for dy := 0; dy < 6 && y0+dy < H; dy++ {
					if int(p.Pix[(y0+dy)*p.Stride+x]) == c {
						bits |= 1 << dy
					}
				}
				row[x] = 63 + bits
				if bits != 0 {
					last = x
				}
			}
			if last < 0 {
				continue
			}
			bw.WriteString("#" + strconv.Itoa(c))
			for x := 0; x <= last; {
				ch := row[x]
				n := 1
				for x+n <= last && row[x+n] == ch {
					n++
				}
				if n > 3 {
					bw.WriteString("!" + strconv.Itoa(n))
					bw.WriteByte(ch)
				} else {
					for k := 0; k < n; k++ {
						bw.WriteByte(ch)
					}
				}
				x += n
			}
			if ci < len(cols)-1 {
				bw.WriteByte('$')
			}
		}
		bw.WriteByte('-')
	}
	bw.WriteString("\x1b\\")
	_, err := w.Write(bw.Bytes())
	return err
}

// FromFile returns the sixel for a picture file: a .six/.sixel file as it
// is, a GIF/PNG/JPEG converted (fitting maxW x maxH pixels).
func FromFile(path string, maxW, maxH int) ([]byte, error) {
	if IsSixelFile(path) {
		return os.ReadFile(path)
	}
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	img, err := Decode(f)
	if err != nil {
		return nil, fmt.Errorf("%s: %v", filepath.Base(path), err)
	}
	var buf bytes.Buffer
	if err := Encode(&buf, Scale(img, maxW, maxH)); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

// Cached is FromFile with the converted pictures kept in dir (by the
// picture's path, size, time and the size asked for).
func Cached(dir, path string, maxW, maxH int) ([]byte, error) {
	st, err := os.Stat(path)
	if err != nil {
		return nil, err
	}
	if IsSixelFile(path) || dir == "" {
		return FromFile(path, maxW, maxH)
	}
	key := fmt.Sprintf("%x-%d-%d-%dx%d", hash(path), st.Size(), st.ModTime().Unix(), maxW, maxH)
	cp := filepath.Join(dir, key+".six")
	if b, err := os.ReadFile(cp); err == nil && len(b) > 0 {
		return b, nil
	}
	b, err := FromFile(path, maxW, maxH)
	if err != nil {
		return nil, err
	}
	if os.MkdirAll(dir, 0o755) == nil {
		os.WriteFile(cp, b, 0o644)
	}
	return b, nil
}

func hash(s string) uint32 {
	h := uint32(2166136261)
	for i := 0; i < len(s); i++ {
		h ^= uint32(s[i])
		h *= 16777619
	}
	return h
}
