package sixel

import (
	"bytes"
	"image"
	"image/color"
	"image/png"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestEncode(t *testing.T) {
	img := image.NewRGBA(image.Rect(0, 0, 1200, 30))
	for x := 0; x < 1200; x++ {
		for y := 0; y < 30; y++ {
			img.Set(x, y, color.RGBA{uint8(x), uint8(y * 8), 128, 255})
		}
	}
	dir := t.TempDir()
	p := filepath.Join(dir, "pic.png")
	f, _ := os.Create(p)
	png.Encode(f, img)
	f.Close()
	b, err := Cached(filepath.Join(dir, "cache"), p, 640, 400)
	if err != nil {
		t.Fatal(err)
	}
	s := string(b)
	if !strings.HasPrefix(s, "\x1bP0;1;0q\"1;1;640;16") || !strings.HasSuffix(s, "-\x1b\\") || !strings.Contains(s, "#0;2;") {
		t.Fatalf("%q", s[:60])
	}
	if n := strings.Count(s, "-"); n != 3 { // 16 rows = 3 bands
		t.Fatalf("bands %d", n)
	}
	if m, _ := filepath.Glob(filepath.Join(dir, "cache", "*.six")); len(m) != 1 {
		t.Fatal("not cached")
	}
	// a ready-made .six is sent as it is
	os.WriteFile(filepath.Join(dir, "a.sixel"), []byte("\x1bPqraw\x1b\\"), 0o644)
	if b, _ := Cached(dir, filepath.Join(dir, "a.sixel"), 640, 400); !bytes.Equal(b, []byte("\x1bPqraw\x1b\\")) {
		t.Fatalf("%q", b)
	}
	if !IsPicture("X.JPEG") || IsPicture("x.txt") {
		t.Fatal("IsPicture")
	}
}
