// Package ansiedit is the ANSI drawing program shared by the BBS's web
// pages (Sysop -> ANSI editor, which works on the text folder) and godrawr
// (the stand-alone program, which works on the files of the computer it
// runs on): an 80-column screen of VGA characters drawn in the spirit of
// Moebius, with Open and Save As dialogs (search, preview), a sixel
// viewer and a picture importer.  The drawing code is static/ansiedit.js;
// the page that holds it talks to its host through a small API:
//
//	GET  {api}/list?dir=D     the folder: {dir, parent, roots, dirs, files}
//	GET  {api}/file?dir=D&name=N           a file's bytes
//	POST {api}/save   dir, name, ext, data (base64)      -> a message
//	POST {api}/sixel  dir, name, png (data URL) or picture (a file)
//	                  -> NAME.SIXEL; a message
package ansiedit

import (
	"bytes"
	"embed"
	"html/template"
	"io/fs"
	"net/http"
)

//go:embed static
var staticFS embed.FS

// Static is the editor's files: ansiedit.js, ansiedit.css, vga8x16.bin
// (and app.css, the stand-alone program's page).
func Static() fs.FS {
	s, _ := fs.Sub(staticFS, "static")
	return s
}

// Handler serves Static (mount it with http.StripPrefix).
func Handler() http.Handler { return http.FileServer(http.FS(Static())) }

// Options say where the editor is.
type Options struct {
	Mode   string // "bbs" (the text folder, screen names) or "app" (any file)
	API    string // the API's address, e.g. /sysop/ansiedit
	Static string // where Static is served, e.g. /static/ae
	Token  string // sent with each POST as csrf (the BBS) / token (godrawr)
	MaxW   int    // sixel pictures: the largest size
	MaxH   int
	Title  string // the program's name (godrawr)
	Open   string // a file to open at start (godrawr: dir|name)
}

var page = template.Must(template.New("ae").Parse(editorHTML))

// Markup is the editor, to put in a page (with its stylesheet and script).
func Markup(o Options) template.HTML {
	if o.MaxW <= 0 {
		o.MaxW = 640
	}
	if o.MaxH <= 0 {
		o.MaxH = 480
	}
	var b bytes.Buffer
	page.Execute(&b, o)
	return template.HTML(b.String())
}

const editorHTML = `<link rel="stylesheet" href="{{.Static}}/ansiedit.css">
<div id="ae" data-mode="{{.Mode}}" data-api="{{.API}}" data-static="{{.Static}}" data-token="{{.Token}}" data-maxw="{{.MaxW}}" data-maxh="{{.MaxH}}" data-open="{{.Open}}">
<div class="ae-bar ae-filebar">
 <button type="button" id="ae-open" title="Ctrl+O: find and open a screen, a sixel or a picture">Open&hellip;</button>
 <button type="button" id="ae-save" title="Ctrl+S: save it again, as the same file">Save</button>
 <button type="button" id="ae-saveas" title="Ctrl+Shift+S: save under another name or as another kind of file">Save As&hellip;</button>
 <button type="button" id="ae-export" class="ghost" title="Save a picture of the drawing as a sixel (.SIXEL)">Export Sixel&hellip;</button>
 <button type="button" id="ae-new" class="ghost" title="A new, empty screen">New</button>
 <button type="button" id="ae-import" class="ghost" title="Draw a picture (PNG, GIF, JPEG or sixel) into the screen with half-blocks">Import Picture&hellip;</button>
 <button type="button" id="ae-view" class="ghost" title="Look at a sixel picture">Sixel Viewer&hellip;</button>
 <span class="ae-file"><span class="dim">Editing</span> <b id="ae-filename">Untitled</b><span id="ae-dirty" class="ae-dirtymark" hidden> &bull; not saved</span></span>
</div>
<div class="ae-bar ae-optbar">
 <label>Rows <input id="ae-rows" type="number" min="1" max="1000" value="25"></label>
 <label>Zoom <select id="ae-zoom"><option value="1" selected>1x</option><option value="2">2x</option><option value="3">3x</option></select></label>
 <label title="The saved screen starts by clearing the caller's screen"><input type="checkbox" id="ae-cls" checked> Clear screen first</label>
 <label title="Bright backgrounds (8-15) instead of blinking"><input type="checkbox" id="ae-ice" checked> iCE colours</label>
</div>
<div class="ae-main">
 <div class="ae-tools" id="ae-tools">
  <button type="button" data-tool="keys" title="Type: arrows move, F1-F10 the character set, Enter, Backspace, Delete, Insert">Keyboard</button>
  <button type="button" data-tool="brush" title="Draw the selected character in the selected colours">Brush</button>
  <button type="button" data-tool="half" title="Half-block brush: two pixels per character cell (Moebius)">Half-block</button>
  <button type="button" data-tool="shade" title="Shading: each pass goes darker-lighter through the shade blocks; Shift lightens">Shade</button>
  <button type="button" data-tool="colour" title="Change only the colours of the cells you paint">Colourize</button>
  <button type="button" data-tool="line" title="Line of half-blocks">Line</button>
  <button type="button" data-tool="rect" title="Rectangle outline (half-blocks)">Rectangle</button>
  <button type="button" data-tool="frect" title="Filled rectangle (half-blocks)">Filled rect</button>
  <button type="button" data-tool="fill" title="Fill an area of one colour (half-blocks)">Fill</button>
  <button type="button" data-tool="erase" title="Erase to blank">Erase</button>
  <button type="button" data-tool="pick" title="Pick the character and colours of a cell (Alt+click in any tool)">Pick</button>
  <button type="button" data-tool="select" title="Select an area: drag inside it to move it; Ctrl+C copy, Ctrl+X cut, Ctrl+V paste, Delete clears">Select</button>
  <div id="ae-selbar" class="ae-selbar">
   <button type="button" id="ae-copy" class="ghost" title="Ctrl+C" disabled>Copy</button>
   <button type="button" id="ae-cut" class="ghost" title="Ctrl+X" disabled>Cut</button>
   <button type="button" id="ae-del" class="ghost" title="Delete" disabled>Delete</button>
   <button type="button" id="ae-paste" class="ghost" title="Ctrl+V: then click where it goes, as many times as you like" disabled>Paste</button>
   <button type="button" id="ae-stop" class="ghost" title="Esc" hidden>Done pasting</button>
  </div>
  <label>Size <select id="ae-size"><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option></select></label>
  <button type="button" id="ae-undo" class="ghost" title="Ctrl+Z">Undo</button>
  <button type="button" id="ae-redo" class="ghost" title="Ctrl+Y">Redo</button>
 </div>
 <div class="ae-scroll"><div class="ae-stage" id="ae-stage"><canvas id="ae-canvas"></canvas><canvas id="ae-over"></canvas></div></div>
 <div class="ae-side">
  <div class="ae-cur"><canvas id="ae-swatch" width="64" height="48"></canvas><span id="ae-curtext"></span></div>
  <div class="ae-pal" id="ae-pal"></div>
  <p class="small dim">Click: foreground. Right click: background. X swaps.</p>
  <label class="small">True colour fg <input type="color" id="ae-fgrgb" value="#ff8800"></label>
  <label class="small">True colour bg <input type="color" id="ae-bgrgb" value="#202040"></label>
  <p class="small dim">A true colour makes the screen high colour: save it as .ANSI ({{if eq .Mode "bbs"}}callers with 256 or more colours; the others get NAME.ANS or the built-in screen{{else}}terminals with 256 or more colours{{end}}).</p>
  <div class="ae-fkeys"><button type="button" id="ae-fprev" class="ghost">&lsaquo;</button><span id="ae-fset"></span><button type="button" id="ae-fnext" class="ghost">&rsaquo;</button></div>
  <div id="ae-fkeyrow" class="ae-fkeyrow"></div>
  <canvas id="ae-chars" width="256" height="256" title="Pick the brush character"></canvas>
 </div>
</div>
<p id="ae-status" class="small"></p>
<details class="card ae-help"><summary>Help</summary>
<ul class="small">
<li><b>Files</b>: Open&hellip; (Ctrl+O) shows the {{if eq .Mode "bbs"}}screens in the BBS's text folder{{else}}folders of this computer{{end}}: type in Search to find one, click it to see it, double-click (or Open) to open it.{{if eq .Mode "bbs"}} &ldquo;From my computer&hellip;&rdquo; opens a file of your own computer instead.{{end}} Save (Ctrl+S) saves the same file again; Save As&hellip; (Ctrl+Shift+S) picks the name and the kind: .ANS (16 colours), .ANSI (high colour; NAME.ANSI1 to NAME.ANSI9 are random variants), .ASC (pipe codes) or .SIXEL (a picture of the drawing). Export Sixel&hellip; saves the drawing as a sixel{{if eq .Mode "app"}} (at most {{.MaxW}}&times;{{.MaxH}}, the BBS's size, or full size){{end}}.</li>
{{if eq .Mode "bbs"}}<li><b>Screens</b>: NAME.SIXEL is shown to callers with sixel, NAME.ANSI (and NAME.ANSI1-9, picked at random) to callers with 256 or more colours, NAME.ANS to the others; with none of them the BBS shows its built-in screen or menu.</li>{{end}}
<li><b>Sixel</b>: opening a .SIXEL (or a PNG, GIF or JPEG) shows it in the sixel viewer: zoom, then Import into the drawing, or Save as .SIXEL. Import Picture&hellip; draws a picture into the screen in half-blocks (two pixels a cell), in 16 colours or true colour.</li>
<li><b>Lightbar menus</b>: type ~01, ~02 ... where each item goes and ~HP where its help line goes.</li>
<li><b>Select</b>: drag a box; drag inside it to move it.  Copy / Cut / Delete (Ctrl+C, Ctrl+X, Delete); Paste (Ctrl+V) and click where it goes &mdash; each click stamps another copy; arrows nudge it, Enter stamps, Esc or right click stops.</li>
<li><b>Keys</b>: F1-F10 type the characters of the set shown (&lsaquo; &rsaquo; or Ctrl+Left/Right change the set); Alt+click picks colours; Ctrl+Z / Ctrl+Y undo and redo; Ctrl+A selects all.</li>
<li><b>Colours</b>: bright backgrounds (8-15) need iCE colours on the {{if eq .Mode "bbs"}}caller's {{end}}terminal.</li>
</ul>
</details>
</div>
<script src="{{.Static}}/ansiedit.js"></script>`
