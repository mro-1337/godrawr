// ANSI editor in the spirit of Moebius -- the BBS's web pages (Sysop ->
// ANSI editor, on the text folder) and godrawr (the stand-alone program,
// on the computer's own files): an 80 column text screen of 8x16 VGA
// character cells (code page 437) drawn with the keyboard (F-key character
// sets), a character brush, the half-block brush, shading, colourizing,
// lines, rectangles, fill and select / copy / paste, with undo.  Colours
// are the 16 PC colours or true colour.  Files: Open and Save As dialogs
// (search, preview), NAME.ANS (16 colours), NAME.ANSI / NAME.ANSI1-9 (high
// colour), NAME.ASC (pipe codes) and NAME.SIXEL (the drawing as a
// picture); a sixel viewer; pictures and sixels imported in half-blocks.
(function () {
  'use strict';
  var root = document.getElementById('ae');
  if (!root) return;
  var MODE = root.getAttribute('data-mode') || 'bbs', APP = MODE === 'app';
  var API = root.getAttribute('data-api'), TOKEN = root.getAttribute('data-token');
  var MAXW = parseInt(root.getAttribute('data-maxw'), 10) || 640, MAXH = parseInt(root.getAttribute('data-maxh'), 10) || 480;
  var COLS = 80, CW = 8, CH = 16, MAXROWS = 1000;
  var PAL = [0x000000, 0x0000aa, 0x00aa00, 0x00aaaa, 0xaa0000, 0xaa00aa, 0xaa5500, 0xaaaaaa,
    0x555555, 0x5555ff, 0x55ff55, 0x55ffff, 0xff5555, 0xff55ff, 0xffff55, 0xffffff];
  var A2D = [0, 4, 2, 6, 1, 5, 3, 7]; // ANSI colour number <-> PC colour number
  var CUSTOM = 0x1000000;             // a colour value with this bit is 0xRRGGBB
  var CP = '\u0000☺☻♥♦♣♠•◘○◙♂♀♪♫☼' +
    '►◄↕‼¶§▬↨↑↓→←∟↔▲▼' +
    ' !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~⌂' +
    'ÇüéâäàåçêëèïîìÄÅ' +
    'ÉæÆôöòûùÿÖÜ¢£¥₧ƒ' +
    'áíóúñÑªº¿⌐¬½¼¡«»' +
    '░▒▓│┤╡╢╖╕╣║╗╝╜╛┐' +
    '└┴┬├─┼╞╟╚╔╩╦╠═╬╧' +
    '╨╤╥╙╘╒╓╫╪┘┌█▄▌▐▀' +
    'αßΓπΣσµτΦΘΩδ∞φε∩' +
    '≡±≥≤⌠⌡÷≈°∙·√ⁿ²■ ';
  var UNI = {};
  for (var u = 32; u < 256; u++) UNI[CP.charAt(u)] = u;
  // F-key character sets (as in PabloDraw and Moebius)
  var FSETS = [
    [218, 191, 192, 217, 196, 179, 195, 180, 193, 194], [201, 187, 200, 188, 205, 186, 204, 185, 202, 203],
    [213, 184, 212, 190, 205, 179, 198, 181, 207, 209], [214, 183, 211, 189, 196, 186, 199, 182, 208, 210],
    [197, 206, 216, 215, 232, 232, 155, 156, 153, 239], [176, 177, 178, 219, 223, 220, 221, 222, 254, 250],
    [1, 2, 3, 4, 5, 6, 240, 14, 15, 32], [24, 25, 30, 31, 16, 17, 18, 29, 20, 21],
    [174, 175, 242, 243, 169, 170, 253, 246, 171, 172], [227, 241, 244, 245, 234, 157, 228, 248, 251, 252],
    [224, 225, 226, 229, 230, 231, 235, 236, 237, 238], [128, 135, 165, 164, 152, 159, 247, 249, 173, 168],
    [131, 132, 133, 160, 166, 134, 142, 143, 145, 146], [136, 137, 138, 130, 144, 140, 139, 141, 161, 158],
    [147, 148, 149, 162, 167, 150, 129, 151, 163, 154], [47, 92, 40, 41, 123, 125, 91, 93, 96, 39]];

  function $(id) { return document.getElementById(id); }
  var cv = $('ae-canvas'), ov = $('ae-over'), stage = $('ae-stage');
  var ctx = cv.getContext('2d', { alpha: false }), octx = ov.getContext('2d');
  var font = null, img = null, fb = null, dirty = true, bulk = false, changed = false;
  var LITTLE = new Uint8Array(new Uint32Array([1]).buffer)[0] === 1;

  // ---- the document
  var rows = 25, chA, fgA, bgA;
  function alloc(n) {
    var c = new Uint8Array(COLS * n), f = new Int32Array(COLS * n), b = new Int32Array(COLS * n);
    c.fill(32); f.fill(7); b.fill(0);
    if (chA) {
      var k = Math.min(chA.length, c.length);
      c.set(chA.subarray(0, k)); f.set(fgA.subarray(0, k)); b.set(bgA.subarray(0, k));
    }
    chA = c; fgA = f; bgA = b; rows = n;
    cv.width = ov.width = COLS * CW; cv.height = ov.height = rows * CH;
    img = ctx.createImageData(cv.width, cv.height);
    fb = new Uint32Array(img.data.buffer);
    $('ae-rows').value = rows;
    zoom();
    redrawAll();
  }
  function ensureRows(y) { if (y >= rows && y < MAXROWS) alloc(Math.min(MAXROWS, y + 1)); }

  var curFg = 7, curBg = 0, curCh = 219, tool = 'half', size = 1, fset = 5;
  var cx = 0, cy = 0, insert = false;
  var undoS = [], redoS = [];

  function rgbOf(v) { return v >= CUSTOM ? v & 0xffffff : PAL[v & 15]; }
  function isCustom(v) { return v >= CUSTOM; }
  function px(rgb) {
    var r = rgb >> 16 & 255, g = rgb >> 8 & 255, b = rgb & 255;
    return LITTLE ? (0xff000000 | b << 16 | g << 8 | r) >>> 0 : ((r << 24 | g << 16 | b << 8 | 255) >>> 0);
  }
  function drawCell(i) {
    if (!font || bulk) return;
    var x = i % COLS, y = (i / COLS) | 0, g = chA[i] * 16;
    var f = px(rgbOf(fgA[i])), b = px(rgbOf(bgA[i])), w = cv.width;
    var o = y * CH * w + x * CW;
    for (var r = 0; r < CH; r++, o += w) {
      var bits = font[g + r];
      for (var c = 0; c < 8; c++) fb[o + c] = (bits & (0x80 >> c)) ? f : b;
    }
    dirty = true;
  }
  function redrawAll() { for (var i = 0; i < COLS * rows; i++) drawCell(i); dirty = true; }
  function set(x, y, c, f, b) {
    if (x < 0 || x >= COLS || y < 0) return;
    ensureRows(y);
    if (y >= rows) return;
    var i = y * COLS + x;
    if (c != null) chA[i] = c;
    if (f != null) fgA[i] = f;
    if (b != null) bgA[i] = b;
    drawCell(i);
  }
  function at(x, y) { var i = y * COLS + x; return { ch: chA[i], fg: fgA[i], bg: bgA[i] }; }

  // ---- undo
  function snap() { return { rows: rows, ch: chA.slice(), fg: fgA.slice(), bg: bgA.slice() }; }
  function restore(s) { chA = null; alloc(s.rows); chA.set(s.ch); fgA.set(s.fg); bgA.set(s.bg); redrawAll(); }
  function pushUndo() { if (!changed) { changed = true; fileUI(); } undoS.push(snap()); if (undoS.length > 60) undoS.shift(); redoS = []; }
  function undo() { if (undoS.length) { redoS.push(snap()); restore(undoS.pop()); status(); } }
  function redo() { if (redoS.length) { undoS.push(snap()); restore(redoS.pop()); status(); } }

  // ---- half-blocks: two pixels per cell (rows*2 high)
  function ice() { return $('ae-ice').checked; }
  function halves(x, y) {
    var c = at(x, y);
    switch (c.ch) {
      case 219: return [c.fg, c.fg];
      case 223: return [c.fg, c.bg];
      case 220: return [c.bg, c.fg];
      default: return [c.bg, c.bg];
    }
  }
  function canBg(v) { return isCustom(v) || v < 8 || ice(); }
  function setHalf(x, hy, col) {
    if (x < 0 || x >= COLS || hy < 0) return;
    var y = hy >> 1;
    ensureRows(y);
    if (y >= rows) return;
    var h = halves(x, y);
    h[hy & 1] = col;
    var t = h[0], b = h[1];
    if (t === b) set(x, y, 219, t, at(x, y).bg);
    else if (canBg(b)) set(x, y, 223, t, b);
    else if (canBg(t)) set(x, y, 220, b, t);
    else set(x, y, 223, t, b);
  }
  function halfAt(x, hy) { return halves(x, hy >> 1)[hy & 1]; }
  function line(x0, y0, x1, y1) {
    var out = [], dx = Math.abs(x1 - x0), sx = x0 < x1 ? 1 : -1, dy = Math.abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    var err = (dx > dy ? dx : -dy) / 2;
    for (;;) {
      out.push([x0, y0]);
      if (x0 === x1 && y0 === y1) break;
      var e2 = err;
      if (e2 > -dx) { err -= dy; x0 += sx; }
      if (e2 < dy) { err += dx; y0 += sy; }
    }
    return out;
  }
  function blot(fn, x, y) {
    var o = -Math.floor(size / 2);
    for (var a = 0; a < size; a++) for (var b = 0; b < size; b++) fn(x + o + a, y + o + b);
  }
  function shade(x, y, lighter) {
    if (x < 0 || x >= COLS || y < 0 || y >= rows) return;
    var c = at(x, y), n;
    if (lighter) {
      n = { 176: 32, 177: 176, 178: 177, 219: 178 }[c.ch];
      if (n == null || (c.ch === 219 && c.fg !== curFg)) return;
    } else {
      n = { 178: 219, 177: 178, 176: 177 }[c.ch];
      if (c.ch === 219) { if (c.fg === curFg) return; n = 176; }
      if (n == null) n = 176;
    }
    set(x, y, n, curFg, curBg);
  }
  function fillHalf(x, hy, col) {
    var from = halfAt(x, hy);
    if (from === col) return;
    var H = rows * 2, seen = new Uint8Array(COLS * H), st = [[x, hy]];
    while (st.length) {
      var p = st.pop(), a = p[0], b = p[1];
      if (a < 0 || a >= COLS || b < 0 || b >= H || seen[b * COLS + a] || halfAt(a, b) !== from) continue;
      seen[b * COLS + a] = 1;
      setHalf(a, b, col);
      st.push([a + 1, b], [a - 1, b], [a, b + 1], [a, b - 1]);
    }
  }

  // ---- drawing on the canvas
  var zoomN = 2;
  function zoom() {
    zoomN = parseInt($('ae-zoom').value, 10) || 1;
    [cv, ov].forEach(function (c) { c.style.width = (COLS * CW * zoomN) + 'px'; c.style.height = (rows * CH * zoomN) + 'px'; });
    stage.style.width = (COLS * CW * zoomN) + 'px';
    stage.style.height = (rows * CH * zoomN) + 'px';
  }
  function pos(e) {
    var r = ov.getBoundingClientRect();
    var x = (e.clientX - r.left) / (r.width / ov.width), y = (e.clientY - r.top) / (r.height / ov.height);
    return { x: Math.floor(x / CW), y: Math.floor(y / CH), hy: Math.floor(y / (CH / 2)) };
  }
  var down = null, last = null, sel = null, hover = null;
  function colourFor(btn) { return btn === 2 ? curBg : curFg; }
  function paint(p, btn, e) {
    switch (tool) {
      case 'brush': blot(function (x, y) { set(x, y, curCh, curFg, curBg); }, p.x, p.y); break;
      case 'erase': blot(function (x, y) { set(x, y, 32, 7, 0); }, p.x, p.y); break;
      case 'colour': blot(function (x, y) { if (y < rows && x >= 0 && x < COLS) { if (btn === 2) set(x, y, null, null, curBg); else set(x, y, null, curFg, null); } }, p.x, p.y); break;
      case 'shade': blot(function (x, y) { shade(x, y, e.shiftKey || btn === 2); }, p.x, p.y); break;
      case 'half': blot(function (x, y) { setHalf(x, y, colourFor(btn)); }, p.x, p.hy); break;
    }
  }
  function stroke(a, b, btn, e) {
    if (tool === 'half') line(a.x, a.hy, b.x, b.hy).forEach(function (q) { paint({ x: q[0], hy: q[1], y: q[1] >> 1 }, btn, e); });
    else line(a.x, a.y, b.x, b.y).forEach(function (q) { paint({ x: q[0], y: q[1], hy: q[1] * 2 }, btn, e); });
  }
  function pick(p) {
    if (p.y >= rows) return;
    var c = at(p.x, p.y);
    curCh = c.ch; curFg = c.fg; curBg = c.bg;
    if (tool === 'half') curFg = halfAt(p.x, p.hy);
    ui();
  }
  ov.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  ov.addEventListener('mousedown', function (e) {
    e.preventDefault();
    if (!chA) return; // still starting
    stage.focus();
    var p = pos(e);
    if (floating) { // a paste or a move: stamp it here (right click: stop)
      if (e.button === 2) { endFloat(); return; }
      stamp();
      if (floating.move) endFloat(); else msg('Pasted. Click to paste again, Esc or right click to stop.');
      return;
    }
    if (e.altKey || tool === 'pick') { pick(p); return; }
    if (tool === 'keys') { cx = p.x; cy = Math.min(p.y, rows - 1); overlay(); status(); return; }
    if (tool === 'select') {
      if (sel && inSel(p)) { startMove(p); return; } // drag the selection to move it
      sel = { x0: p.x, y0: p.y, x1: p.x, y1: p.y }; down = { p: p, btn: e.button }; overlay(); selBar(); return;
    }
    pushUndo();
    down = { p: p, btn: e.button };
    last = p;
    if (tool === 'fill') { fillHalf(p.x, p.hy, colourFor(e.button)); down = null; return; }
    if (tool === 'line' || tool === 'rect' || tool === 'frect') { overlay(); return; }
    paint(p, e.button, e);
  });
  window.addEventListener('mousemove', function (e) {
    if (!chA || modalOpen) return;
    var p = pos(e);
    hover = p;
    if (floating) { floating.x = p.x - floating.gx; floating.y = p.y - floating.gy; overlay(); return; }
    if (!down) { overlay(); status(); return; }
    if (tool === 'select') { sel.x1 = p.x; sel.y1 = p.y; overlay(); return; }
    if (tool === 'line' || tool === 'rect' || tool === 'frect') { last = p; overlay(); return; }
    stroke(last, p, down.btn, e);
    last = p;
    status();
  });
  window.addEventListener('mouseup', function () {
    if (floating && floating.move && floating.dragging) { // a move by dragging: drop it
      floating.dragging = false;
      stamp();
      endFloat();
      return;
    }
    if (!down) return;
    var a = down.p, b = last || a, col = colourFor(down.btn);
    if (tool === 'line') line(a.x, a.hy, b.x, b.hy).forEach(function (q) { setHalf(q[0], q[1], col); });
    if (tool === 'rect' || tool === 'frect') {
      var x0 = Math.min(a.x, b.x), x1 = Math.max(a.x, b.x), y0 = Math.min(a.hy, b.hy), y1 = Math.max(a.hy, b.hy);
      for (var y = y0; y <= y1; y++) for (var x = x0; x <= x1; x++)
        if (tool === 'frect' || x === x0 || x === x1 || y === y0 || y === y1) setHalf(x, y, col);
    }
    down = null; last = null;
    overlay();
  });

  function overlay() {
    octx.clearRect(0, 0, ov.width, ov.height);
    octx.lineWidth = 1;
    if (tool === 'keys') {
      octx.strokeStyle = insert ? '#ff0' : '#fff';
      octx.strokeRect(cx * CW + 0.5, cy * CH + 0.5, CW - 1, CH - 1);
      octx.fillStyle = 'rgba(255,255,255,0.5)';
      octx.fillRect(cx * CW, cy * CH + CH - 2, CW, 2);
    }
    if (floating) {
      if (!floating.img) floating.img = clipImage(floating.clip);
      octx.globalAlpha = 0.85;
      octx.drawImage(floating.img, floating.x * CW, floating.y * CH);
      octx.globalAlpha = 1;
      octx.strokeStyle = '#0ff';
      octx.setLineDash([4, 2]);
      octx.strokeRect(floating.x * CW + 0.5, floating.y * CH + 0.5, floating.clip.w * CW - 1, floating.clip.h * CH - 1);
      octx.setLineDash([]);
      return;
    }
    if (sel) {
      var r = selRect();
      octx.strokeStyle = '#ff0';
      octx.setLineDash([3, 3]);
      octx.strokeRect(r.x * CW + 0.5, r.y * CH + 0.5, r.w * CW - 1, r.h * CH - 1);
      octx.setLineDash([]);
    }
    if (down && last && (tool === 'line' || tool === 'rect' || tool === 'frect')) {
      octx.fillStyle = '#' + ('00000' + rgbOf(colourFor(down.btn)).toString(16)).slice(-6);
      var a = down.p, b = last;
      if (tool === 'line') line(a.x, a.hy, b.x, b.hy).forEach(function (q) { octx.fillRect(q[0] * CW, q[1] * CH / 2, CW, CH / 2); });
      else {
        var x0 = Math.min(a.x, b.x), x1 = Math.max(a.x, b.x), y0 = Math.min(a.hy, b.hy), y1 = Math.max(a.hy, b.hy);
        if (tool === 'frect') octx.fillRect(x0 * CW, y0 * CH / 2, (x1 - x0 + 1) * CW, (y1 - y0 + 1) * CH / 2);
        else {
          octx.strokeStyle = octx.fillStyle; octx.lineWidth = 4;
          octx.strokeRect(x0 * CW + 4, y0 * CH / 2 + 4, (x1 - x0 + 1) * CW - 8, (y1 - y0 + 1) * CH / 2 - 8);
        }
      }
    } else if (hover && tool !== 'keys' && tool !== 'select' && hover.y < rows) {
      octx.strokeStyle = 'rgba(255,255,0,0.7)';
      if (tool === 'half' || tool === 'fill') octx.strokeRect(hover.x * CW + 0.5, hover.hy * CH / 2 + 0.5, CW - 1, CH / 2 - 1);
      else octx.strokeRect(hover.x * CW + 0.5, hover.y * CH + 0.5, CW - 1, CH - 1);
    }
  }
  function selRect() {
    var x = Math.max(0, Math.min(sel.x0, sel.x1)), y = Math.max(0, Math.min(sel.y0, sel.y1));
    var x1 = Math.min(COLS - 1, Math.max(sel.x0, sel.x1)), y1 = Math.min(rows - 1, Math.max(sel.y0, sel.y1));
    return { x: x, y: y, w: x1 - x + 1, h: y1 - y + 1 };
  }

  // ---- clipboard: copy / cut / delete a selection, paste (stamp as many
  // times as wanted), move a selection by dragging it
  var clip = null, floating = null;
  function grab(r) {
    var c = { w: r.w, h: r.h, ch: [], fg: [], bg: [] };
    for (var y = 0; y < r.h; y++) for (var x = 0; x < r.w; x++) {
      var a = at(r.x + x, r.y + y);
      c.ch.push(a.ch); c.fg.push(a.fg); c.bg.push(a.bg);
    }
    return c;
  }
  function blank(r) { for (var y = 0; y < r.h; y++) for (var x = 0; x < r.w; x++) set(r.x + x, r.y + y, 32, 7, 0); }
  function copy(cut) {
    if (!sel) { msg('Select something first (the Select tool).'); return; }
    var r = selRect();
    clip = grab(r);
    if (cut) { pushUndo(); blank(r); sel = null; }
    msg((cut ? 'Cut ' : 'Copied ') + r.w + 'x' + r.h + '. Paste (Ctrl+V) and click where it goes - as many times as you like.');
    selBar(); overlay();
  }
  function paste() {
    if (!clip) { msg('Nothing copied yet.'); return; }
    var h = hover && hover.x >= 0 && hover.y >= 0 ? hover : { x: cx, y: cy };
    floating = { clip: clip, x: h.x, y: h.y, gx: 0, gy: 0, move: false };
    if (tool !== 'select') { tool = 'select'; ui(); }
    msg('Click where the paste goes (click again for more copies). Arrows nudge it, Enter stamps, Esc or right click stops.');
    selBar(); overlay();
  }
  function stamp() {
    var f = floating;
    if (!f) return;
    pushUndo();
    for (var y = 0; y < f.clip.h; y++) for (var x = 0; x < f.clip.w; x++) {
      var k = y * f.clip.w + x, tx = f.x + x, ty = f.y + y;
      if (tx >= 0 && tx < COLS && ty >= 0 && ty < MAXROWS) set(tx, ty, f.clip.ch[k], f.clip.fg[k], f.clip.bg[k]);
    }
    sel = { x0: f.x, y0: f.y, x1: f.x + f.clip.w - 1, y1: f.y + f.clip.h - 1 };
  }
  function endFloat() { floating = null; selBar(); overlay(); status(); }
  function startMove(p) {
    var r = selRect();
    var c = grab(r);
    pushUndo();
    blank(r);
    floating = { clip: c, x: r.x, y: r.y, gx: p.x - r.x, gy: p.y - r.y, move: true, dragging: true };
    sel = null;
    msg('Moving: let go where it goes.');
    selBar(); overlay();
  }
  function clearSel() {
    if (!sel) return;
    pushUndo();
    blank(selRect());
    msg('Deleted.');
  }
  function inSel(p) { var r = selRect(); return p.x >= r.x && p.x < r.x + r.w && p.y >= r.y && p.y < r.y + r.h; }
  // clipImage draws a clip for the overlay
  function clipImage(c) {
    var cv2 = document.createElement('canvas');
    cv2.width = c.w * CW; cv2.height = c.h * CH;
    var x2 = cv2.getContext('2d'), d = x2.createImageData(cv2.width, cv2.height), v = new Uint32Array(d.data.buffer);
    for (var y = 0; y < c.h; y++) for (var x = 0; x < c.w; x++) {
      var k = y * c.w + x, f = px(rgbOf(c.fg[k])), b = px(rgbOf(c.bg[k])), g = c.ch[k] * 16;
      for (var r = 0; r < CH; r++) {
        var bits = font[g + r], o = (y * CH + r) * cv2.width + x * CW;
        for (var q = 0; q < 8; q++) v[o + q] = (bits & (0x80 >> q)) ? f : b;
      }
    }
    x2.putImageData(d, 0, 0);
    return cv2;
  }
  // the selection buttons
  function selBar() {
    var b = $('ae-selbar');
    if (!b) return;
    var on = !!sel && !floating;
    ['ae-copy', 'ae-cut', 'ae-del'].forEach(function (id) { $(id).disabled = !on; });
    $('ae-paste').disabled = !clip;
    $('ae-stop').hidden = !floating;
  }

  // ---- the keyboard
  function putChar(c) {
    pushUndo();
    ensureRows(cy);
    if (insert) for (var x = COLS - 1; x > cx; x--) { var p = at(x - 1, cy); set(x, cy, p.ch, p.fg, p.bg); }
    set(cx, cy, c, curFg, curBg);
    if (++cx >= COLS) { cx = 0; cy++; ensureRows(cy); if (cy >= rows) cy = rows - 1; }
  }
  stage.addEventListener('keydown', function (e) {
    var k = e.key, ctrl = e.ctrlKey || e.metaKey;
    if (ctrl && !e.altKey) {
      switch (k.toLowerCase()) {
        case 'z': undo(); break;
        case 'y': redo(); break;
        case 'c': copy(false); break;
        case 'x': copy(true); overlay(); break;
        case 'v': paste(); break;
        case 'd': sel = null; endFloat(); break;
        case 'a': sel = { x0: 0, y0: 0, x1: COLS - 1, y1: rows - 1 }; overlay(); break;
        case 'arrowleft': fset = (fset + FSETS.length - 1) % FSETS.length; fkeys(); break;
        case 'arrowright': fset = (fset + 1) % FSETS.length; fkeys(); break;
        default: return;
      }
      e.preventDefault();
      return;
    }
    var fn = /^F([1-9]|10)$/.exec(k);
    if (fn) {
      e.preventDefault();
      var c = FSETS[fset][parseInt(fn[1], 10) - 1];
      if (tool === 'keys') putChar(c); else { curCh = c; ui(); }
      overlay(); status();
      return;
    }
    if (floating) {
      var mv = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[k];
      if (mv) { floating.x += mv[0]; floating.y += mv[1]; overlay(); e.preventDefault(); return; }
      if (k === 'Enter') { stamp(); if (floating.move) endFloat(); else overlay(); e.preventDefault(); return; }
      if (k === 'Escape') { endFloat(); e.preventDefault(); return; }
    }
    if (tool !== 'keys') {
      if ((k === 'Delete' || k === 'Backspace') && sel) { clearSel(); e.preventDefault(); }
      else if (k === 'x' || k === 'X') { var t = curFg; curFg = curBg; curBg = t; ui(); }
      else if (k === 'Escape') { sel = null; selBar(); overlay(); }
      return;
    }
    switch (k) {
      case 'ArrowLeft': cx = Math.max(0, cx - 1); break;
      case 'ArrowRight': cx = Math.min(COLS - 1, cx + 1); break;
      case 'ArrowUp': cy = Math.max(0, cy - 1); break;
      case 'ArrowDown': cy++; ensureRows(cy); cy = Math.min(cy, rows - 1); break;
      case 'Home': cx = 0; break;
      case 'End': cx = COLS - 1; break;
      case 'PageUp': cy = Math.max(0, cy - 24); break;
      case 'PageDown': cy = Math.min(rows - 1, cy + 24); break;
      case 'Enter': cx = 0; cy++; ensureRows(cy); cy = Math.min(cy, rows - 1); break;
      case 'Insert': insert = !insert; break;
      case 'Escape': sel = null; break;
      case 'Backspace':
        if (cx > 0) {
          pushUndo(); cx--;
          if (insert) { for (var x = cx; x < COLS - 1; x++) { var q = at(x + 1, cy); set(x, cy, q.ch, q.fg, q.bg); } set(COLS - 1, cy, 32, 7, 0); }
          else set(cx, cy, 32, curFg, curBg);
        }
        break;
      case 'Delete':
        pushUndo();
        for (var d = cx; d < COLS - 1; d++) { var n = at(d + 1, cy); set(d, cy, n.ch, n.fg, n.bg); }
        set(COLS - 1, cy, 32, 7, 0);
        break;
      default:
        if (k.length !== 1 || e.altKey) return;
        putChar(UNI[k] != null ? UNI[k] : 63);
    }
    e.preventDefault();
    overlay(); status();
  });

  // ---- encoding
  function nearest(rgb) {
    var best = 0, bd = 1e9, r = rgb >> 16 & 255, g = rgb >> 8 & 255, b = rgb & 255;
    for (var i = 0; i < 16; i++) {
      var p = PAL[i], d = Math.pow(r - (p >> 16 & 255), 2) + Math.pow(g - (p >> 8 & 255), 2) + Math.pow(b - (p & 255), 2);
      if (d < bd) { bd = d; best = i; }
    }
    return best;
  }
  function to16(v) { return isCustom(v) ? nearest(v & 0xffffff) : v; }
  function customCount() { if (!fgA) return 0; var n = 0; for (var i = 0; i < COLS * rows; i++) if (isCustom(fgA[i]) || isCustom(bgA[i])) n++; return n; }
  function lastCol(y) {
    for (var x = COLS - 1; x >= 0; x--) { var c = at(x, y); if ((c.ch !== 32 && c.ch !== 0 && c.ch !== 255) || c.bg !== 0) return x; }
    return -1;
  }
  function usedRows() { for (var y = rows - 1; y >= 0; y--) if (lastCol(y) >= 0) return y + 1; return 1; }
  function bytesOf(s) { var a = []; for (var i = 0; i < s.length; i++) a.push(s.charCodeAt(i) & 255); return a; }
  function encodeANSI(hi) {
    var out = [], n = usedRows(), state = '';
    if ($('ae-cls').checked) out = out.concat(bytesOf('\x1b[0m\x1b[2J\x1b[1;1H'));
    for (var y = 0; y < n; y++) {
      var lc = lastCol(y);
      for (var x = 0; x <= lc; x++) {
        var c = at(x, y), f = hi ? c.fg : to16(c.fg), b = hi ? c.bg : to16(c.bg);
        if (!hi && !ice() && b >= 8) b -= 8;
        var codes = ['0'];
        if (isCustom(f)) codes.push('38;2;' + (f >> 16 & 255) + ';' + (f >> 8 & 255) + ';' + (f & 255));
        else { if (f >= 8) codes.push('1'); codes.push(String(30 + A2D[f & 7])); }
        if (isCustom(b)) codes.push('48;2;' + (b >> 16 & 255) + ';' + (b >> 8 & 255) + ';' + (b & 255));
        else { if (b >= 8) codes.push('5'); if (b & 7) codes.push(String(40 + A2D[b & 7])); }
        var sgr = '\x1b[' + codes.join(';') + 'm';
        if (sgr !== state) { out = out.concat(bytesOf(sgr)); state = sgr; }
        out.push(c.ch === 0 ? 32 : c.ch);
      }
      if (y < n - 1 && lc < COLS - 1) {
        if (state !== '\x1b[0;37m' && state !== '') { out = out.concat(bytesOf('\x1b[0m')); state = ''; }
        out.push(13, 10);
      }
    }
    out = out.concat(bytesOf('\x1b[0m'));
    return sauce(out, n);
  }
  function encodeASC() {
    var out = [], n = usedRows(), state = -1;
    for (var y = 0; y < n; y++) {
      var lc = lastCol(y);
      for (var x = 0; x <= lc; x++) {
        var c = at(x, y), f = to16(c.fg), b = to16(c.bg) & 7, st = f * 16 + b;
        if (st !== state) {
          out = out.concat(bytesOf('|' + ('0' + f).slice(-2) + '|' + (16 + b)));
          state = st;
        }
        out.push(c.ch === 0 ? 32 : c.ch);
      }
      if (y < n - 1) out.push(13, 10);
    }
    return out;
  }
  function sauce(data, n) {
    var name = (doc.name || 'UNTITLED').toUpperCase();
    var s = [26];
    var field = function (t, len) { for (var i = 0; i < len; i++) s.push(i < t.length ? t.charCodeAt(i) & 255 : 32); };
    var d = new Date(), date = d.getFullYear() + ('0' + (d.getMonth() + 1)).slice(-2) + ('0' + d.getDate()).slice(-2);
    field('SAUCE00', 7); field(name, 35); field('', 20); field('', 20); field(date, 8);
    var size = data.length;
    s.push(size & 255, size >> 8 & 255, size >> 16 & 255, size >>> 24 & 255);
    s.push(1, 1, COLS & 255, COLS >> 8, n & 255, n >> 8, 0, 0, 0, 0, 0);
    s.push((ice() ? 1 : 0) | 2);
    field('IBM VGA', 22);
    return data.concat(s);
  }

  // ---- the toolbar and the side panel
  function hex(v) { return '#' + ('00000' + rgbOf(v).toString(16)).slice(-6); }
  var palEl = $('ae-pal');
  PAL.forEach(function (rgb, i) {
    var b = document.createElement('button');
    b.type = 'button'; b.className = 'ae-sw'; b.title = 'Colour ' + i;
    b.style.background = hex(i);
    b.addEventListener('click', function () { curFg = i; ui(); stage.focus(); });
    b.addEventListener('contextmenu', function (e) { e.preventDefault(); curBg = i; ui(); stage.focus(); });
    palEl.appendChild(b);
  });
  $('ae-fgrgb').addEventListener('input', function () { curFg = CUSTOM | parseInt(this.value.slice(1), 16); ui(); });
  $('ae-bgrgb').addEventListener('input', function () { curBg = CUSTOM | parseInt(this.value.slice(1), 16); ui(); });
  var tools = document.querySelectorAll('#ae-tools [data-tool]');
  Array.prototype.forEach.call(tools, function (b) {
    b.addEventListener('click', function () { tool = b.getAttribute('data-tool'); if (tool !== 'select') { sel = null; floating = null; } selBar(); ui(); stage.focus(); });
  });
  $('ae-size').addEventListener('change', function () { size = parseInt(this.value, 10) || 1; stage.focus(); });
  $('ae-undo').addEventListener('click', undo);
  $('ae-copy').addEventListener('click', function () { copy(false); stage.focus(); });
  $('ae-cut').addEventListener('click', function () { copy(true); stage.focus(); });
  $('ae-del').addEventListener('click', function () { clearSel(); selBar(); stage.focus(); });
  $('ae-paste').addEventListener('click', function () { paste(); stage.focus(); });
  $('ae-stop').addEventListener('click', function () { endFloat(); stage.focus(); });
  $('ae-redo').addEventListener('click', redo);
  $('ae-zoom').addEventListener('change', function () { zoom(); });
  $('ae-rows').addEventListener('change', function () { var n = Math.max(1, Math.min(MAXROWS, parseInt(this.value, 10) || 25)); pushUndo(); alloc(n); status(); });
  $('ae-fprev').addEventListener('click', function () { fset = (fset + FSETS.length - 1) % FSETS.length; fkeys(); });
  $('ae-fnext').addEventListener('click', function () { fset = (fset + 1) % FSETS.length; fkeys(); });
  function fkeys() {
    $('ae-fset').textContent = 'Set ' + (fset + 1);
    var row = $('ae-fkeyrow');
    row.textContent = '';
    FSETS[fset].forEach(function (c, i) {
      var b = document.createElement('button');
      b.type = 'button'; b.className = 'ghost';
      b.textContent = 'F' + (i + 1) + ' ' + CP.charAt(c);
      b.addEventListener('click', function () { if (tool === 'keys') { putChar(c); overlay(); } else { curCh = c; ui(); } stage.focus(); });
      row.appendChild(b);
    });
  }
  var chars = $('ae-chars'), cctx = chars.getContext('2d');
  chars.addEventListener('click', function (e) {
    var r = chars.getBoundingClientRect();
    var x = Math.floor((e.clientX - r.left) / r.width * 16), y = Math.floor((e.clientY - r.top) / r.height * 16);
    curCh = y * 16 + x;
    if (tool !== 'brush' && tool !== 'keys') tool = 'brush';
    ui(); stage.focus();
  });
  function glyph(c2d, c, x0, y0, scale, fgc, bgc) {
    var d = c2d.createImageData(8 * scale, 16 * scale), v = new Uint32Array(d.data.buffer);
    var f = px(fgc), b = px(bgc);
    for (var y = 0; y < 16 * scale; y++) {
      var bits = font[c * 16 + Math.floor(y / scale)];
      for (var x = 0; x < 8 * scale; x++) v[y * 8 * scale + x] = (bits & (0x80 >> Math.floor(x / scale))) ? f : b;
    }
    c2d.putImageData(d, x0, y0);
  }
  function ui() {
    Array.prototype.forEach.call(tools, function (b) { b.classList.toggle('on', b.getAttribute('data-tool') === tool); });
    Array.prototype.forEach.call(palEl.children, function (b, i) {
      b.classList.toggle('fg', curFg === i); b.classList.toggle('bg', curBg === i);
    });
    if (font) {
      var sw = $('ae-swatch').getContext('2d');
      sw.fillStyle = hex(curBg); sw.fillRect(0, 0, 64, 48);
      sw.fillStyle = hex(curFg); sw.fillRect(0, 0, 32, 48);
      glyph(sw, curCh, 40, 8, 2, rgbOf(curFg), rgbOf(curBg));
      cctx.fillStyle = '#000'; cctx.fillRect(0, 0, 256, 256);
      for (var c = 0; c < 256; c++) glyph(cctx, c, (c % 16) * 16 + 4, Math.floor(c / 16) * 16, 1, c === curCh ? 0xffff55 : 0xaaaaaa, c === curCh ? 0x0000aa : 0);
    }
    $('ae-curtext').textContent = 'fg ' + (isCustom(curFg) ? hex(curFg) : curFg) + '  bg ' + (isCustom(curBg) ? hex(curBg) : curBg) + '  char ' + curCh;
    status();
    overlay();
  }
  var note = '';
  function msg(s) { note = s; status(); }
  function status() {
    var p = tool === 'keys' ? (cx + 1) + ',' + (cy + 1) + (insert ? ' INS' : '') : (hover && hover.x >= 0 && hover.x < COLS && hover.y >= 0 && hover.y < rows ? (hover.x + 1) + ',' + (hover.y + 1) : '');
    var hi = customCount();
    $('ae-status').textContent = p + '   ' + rows + ' rows' + (hi ? '   high colour: ' + hi + ' cell(s) in true colour (save as .ANSI)' : '') + (note ? '   — ' + note : '');
  }

  // ---- reading screens (ANSI with 16 / 256 / true colour, pipe codes)
  function xterm256(n) {
    if (n < 16) return n < 8 ? A2D[n] : A2D[n - 8] + 8;
    if (n < 232) {
      n -= 16;
      var lv = function (v) { return v ? 55 + v * 40 : 0; };
      return CUSTOM | lv(Math.floor(n / 36)) << 16 | lv(Math.floor(n / 6) % 6) << 8 | lv(n % 6);
    }
    var g = 8 + (n - 232) * 10;
    return CUSTOM | g << 16 | g << 8 | g;
  }
  // parseScreen reads a screen into a document {rows, ch, fg, bg}.
  function parseScreen(b) {
    var N = COLS * MAXROWS, ch = new Uint8Array(N), fg = new Int32Array(N), bg = new Int32Array(N);
    ch.fill(32); fg.fill(7);
    var x = 0, y = 0, fb0 = 7, bb0 = 0, bold = false, blink = false, fcu = -1, bcu = -1, sx = 0, sy = 0, maxY = 0;
    var curF = function () { return fcu >= 0 ? fcu : fb0 | (bold ? 8 : 0); };
    var curB = function () { return bcu >= 0 ? bcu : bb0 | (blink ? 8 : 0); };
    var put1 = function (px2, py, c, f, b2) { if (px2 >= 0 && px2 < COLS && py >= 0 && py < MAXROWS) { var k = py * COLS + px2; ch[k] = c; fg[k] = f; bg[k] = b2; } };
    var put = function (c) {
      if (x >= COLS) { x = 0; y++; }
      if (y >= MAXROWS) return;
      put1(x, y, c, curF(), curB());
      maxY = Math.max(maxY, y);
      x++;
    };
    var i = 0;
    while (i < b.length) {
      var c = b[i];
      if (c === 26) break;
      if (c === 27 && b[i + 1] === 91) { // ESC [
        var j = i + 2, ps = '';
        while (j < b.length && (b[j] < 64 || b[j] > 126)) ps += String.fromCharCode(b[j++]);
        var fin = String.fromCharCode(b[j]);
        i = j + 1;
        var p = ps.replace(/[?=>]/g, '').split(';').map(function (v) { return v === '' ? NaN : parseInt(v, 10); });
        var n1 = isNaN(p[0]) ? 1 : p[0];
        switch (fin) {
          case 'm':
            if (ps === '') p = [0];
            for (var k = 0; k < p.length; k++) {
              var v = isNaN(p[k]) ? 0 : p[k];
              if (v === 0) { fb0 = 7; bb0 = 0; bold = blink = false; fcu = bcu = -1; }
              else if (v === 1) bold = true;
              else if (v === 22 || v === 2) bold = false;
              else if (v === 5 || v === 6) blink = true;
              else if (v === 25) blink = false;
              else if (v >= 30 && v <= 37) { fb0 = A2D[v - 30]; fcu = -1; }
              else if (v === 39) { fb0 = 7; fcu = -1; }
              else if (v >= 40 && v <= 47) { bb0 = A2D[v - 40]; bcu = -1; }
              else if (v === 49) { bb0 = 0; bcu = -1; }
              else if (v >= 90 && v <= 97) fcu = A2D[v - 90] + 8;
              else if (v >= 100 && v <= 107) bcu = A2D[v - 100] + 8;
              else if ((v === 38 || v === 48) && p[k + 1] === 5) { var x2 = xterm256(p[k + 2] | 0); if (v === 38) fcu = x2; else bcu = x2; k += 2; }
              else if ((v === 38 || v === 48) && p[k + 1] === 2) {
                var rgb = CUSTOM | (p[k + 2] & 255) << 16 | (p[k + 3] & 255) << 8 | (p[k + 4] & 255);
                if (v === 38) fcu = rgb; else bcu = rgb;
                k += 4;
              }
            }
            break;
          case 'H': case 'f': y = (isNaN(p[0]) ? 1 : p[0]) - 1; x = (isNaN(p[1]) ? 1 : p[1]) - 1; break;
          case 'A': y = Math.max(0, y - n1); break;
          case 'B': y += n1; break;
          case 'C': x = Math.min(COLS - 1, x + n1); break;
          case 'D': x = Math.max(0, x - n1); break;
          case 'J': if (p[0] === 2) { ch.fill(32); fg.fill(7); bg.fill(0); x = y = 0; } break;
          case 'K': for (var e2 = x; e2 < COLS; e2++) put1(e2, y, 32, 7, curB()); break;
          case 's': sx = x; sy = y; break;
          case 'u': x = sx; y = sy; break;
        }
        continue;
      }
      if (c === 124 && i + 2 < b.length) { // pipe codes |00-|23, |#RRGGBB
        var two = String.fromCharCode(b[i + 1], b[i + 2]);
        if (/^[0-2][0-9]$/.test(two) && parseInt(two, 10) <= 23) {
          var pv = parseInt(two, 10);
          if (pv < 16) { fb0 = pv & 7; bold = pv >= 8; fcu = pv; } else { bb0 = pv - 16; bcu = -1; blink = false; }
          i += 3; continue;
        }
        if (b[i + 1] === 35) {
          var hx = String.fromCharCode.apply(null, Array.prototype.slice.call(b, i + 2, i + 8));
          if (/^[0-9a-fA-F]{6}$/.test(hx)) { fcu = CUSTOM | parseInt(hx, 16); i += 8; continue; }
        }
      }
      i++;
      switch (c) {
        case 13: x = 0; break;
        case 10: y++; break;
        case 9: x = Math.min(COLS - 1, (x + 8) & ~7); break;
        case 8: x = Math.max(0, x - 1); break;
        case 7: case 0: case 12: break;
        default: put(c);
      }
    }
    var n = Math.max(25, Math.min(MAXROWS, maxY + 1));
    return { rows: n, ch: ch.subarray(0, n * COLS), fg: fg.subarray(0, n * COLS), bg: bg.subarray(0, n * COLS) };
  }
  // loadDoc makes a document the drawing.
  function loadDoc(d) {
    chA = null; alloc(d.rows);
    chA.set(d.ch); fgA.set(d.fg); bgA.set(d.bg);
    redrawAll();
    cx = cy = 0; sel = null; floating = null;
    undoS = []; redoS = []; changed = false;
    selBar(); overlay(); status(); fileUI();
  }
  // docCanvas draws a document (for the previews).
  function docCanvas(d, maxRows) {
    var n = Math.min(d.rows, maxRows || d.rows), c = document.createElement('canvas');
    c.width = COLS * CW; c.height = n * CH;
    var x2 = c.getContext('2d'), im = x2.createImageData(c.width, c.height), v = new Uint32Array(im.data.buffer);
    for (var i = 0; i < n * COLS; i++) {
      var x = i % COLS, y = (i / COLS) | 0, g = d.ch[i] * 16, f = px(rgbOf(d.fg[i])), b = px(rgbOf(d.bg[i])), o = y * CH * c.width + x * CW;
      for (var r = 0; r < CH; r++, o += c.width) {
        var bits = font[g + r];
        for (var q = 0; q < 8; q++) v[o + q] = (bits & (0x80 >> q)) ? f : b;
      }
    }
    x2.putImageData(im, 0, 0);
    return c;
  }

  // ---- sixel pictures: decoding (the viewer, previews, importing)
  function hls(h, l, s) { // sixel HLS: hue 0 is blue
    h = ((h + 240) % 360) / 360; l /= 100; s /= 100;
    if (!s) { var g = Math.round(l * 255); return [g, g, g]; }
    var q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
    var f = function (t) {
      if (t < 0) t += 1; if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    };
    return [Math.round(f(h + 1 / 3) * 255), Math.round(f(h) * 255), Math.round(f(h - 1 / 3) * 255)];
  }
  var VT340 = [[0, 0, 0], [51, 51, 204], [204, 36, 36], [51, 204, 51], [204, 51, 204], [51, 204, 204], [204, 204, 51], [135, 135, 135],
    [66, 66, 66], [84, 84, 153], [153, 66, 66], [84, 153, 84], [153, 84, 153], [84, 153, 153], [153, 153, 84], [204, 204, 204]];
  // decodeSixel draws a sixel picture on a canvas (null: not a sixel)
  function decodeSixel(b) {
    var i = 0, n = b.length;
    for (; i < n; i++) {
      if (b[i] === 0x90) { i++; break; }
      if (b[i] === 27 && b[i + 1] === 80) { i += 2; break; } // ESC P
    }
    if (i >= n) return null;
    while (i < n && b[i] !== 113) i++; // the parameters, up to q
    if (i >= n) return null;
    var start = ++i;
    // first pass: the size
    var W = 0, H = 0, x = 0, band = 0, colours = {};
    var num = function () { var v = 0, any = false; while (i < n && b[i] >= 48 && b[i] <= 57) { v = v * 10 + b[i] - 48; i++; any = true; } return any ? v : -1; };
    var pass = function (paint) {
      var pal = VT340.map(function (c) { return c.slice(); }), cur = pal[0], data = paint, w = W;
      i = start; x = 0; band = 0;
      while (i < n) {
        var c = b[i];
        if (c === 27 || c === 0x9c) break;
        if (c === 34) { // " raster: Pan;Pad;Ph;Pv
          i++; var a = [num()]; while (b[i] === 59) { i++; a.push(num()); }
          if (!paint) { if (a[2] > 0) W = Math.max(W, a[2]); if (a[3] > 0) H = Math.max(H, a[3]); }
          continue;
        }
        if (c === 35) { // # colour
          i++; var reg = num(), args = [];
          while (b[i] === 59) { i++; args.push(num()); }
          if (args.length >= 4) {
            var rgb = args[0] === 1 ? hls(args[1], args[2], args[3]) : [Math.round(args[1] * 2.55), Math.round(args[2] * 2.55), Math.round(args[3] * 2.55)];
            pal[reg & 1023] = rgb; colours[reg] = 1;
          }
          cur = pal[reg & 1023] || [0, 0, 0];
          continue;
        }
        if (c === 33) { // ! repeat
          i++; var rep = Math.max(1, num()), ch = b[i++];
          if (ch >= 63 && ch <= 126) { if (paint) put6(data, w, x, band, ch - 63, cur, rep); x += rep; if (x > W && !paint) W = x; }
          continue;
        }
        if (c === 36) { x = 0; i++; continue; }            // $ carriage return
        if (c === 45) { x = 0; band += 6; i++; continue; } // - next band
        if (c >= 63 && c <= 126) {
          if (paint) put6(data, w, x, band, c - 63, cur, 1);
          x++; if (!paint && x > W) W = x;
          if (!paint && (c - 63) && band + 6 > H) H = Math.max(H, band + bitsHigh(c - 63));
          i++; continue;
        }
        i++;
      }
      if (!paint) H = Math.max(H, band + (x ? 6 : 0));
    };
    var bitsHigh = function (v) { var h = 0; for (var k = 0; k < 6; k++) if (v & (1 << k)) h = k + 1; return h; };
    var put6 = function (data, w, x0, y0, v, rgb, rep) {
      for (var k = 0; k < 6; k++) {
        if (!(v & (1 << k))) continue;
        var y = y0 + k;
        if (y >= H) continue;
        for (var r = 0; r < rep; r++) {
          var xx = x0 + r;
          if (xx >= w) break;
          var o = (y * w + xx) * 4;
          data[o] = rgb[0]; data[o + 1] = rgb[1]; data[o + 2] = rgb[2]; data[o + 3] = 255;
        }
      }
    };
    pass(null);
    if (W < 1 || H < 1 || W * H > 40e6) return null;
    var cv2 = document.createElement('canvas');
    cv2.width = W; cv2.height = H;
    var x2 = cv2.getContext('2d'), im = x2.createImageData(W, H);
    for (var k = 3; k < im.data.length; k += 4) im.data[k] = 255; // a black background
    pass(im.data);
    x2.putImageData(im, 0, 0);
    cv2.colours = Object.keys(colours).length;
    return cv2;
  }
  function pictureCanvas(bytes, name) { // a sixel, PNG, GIF or JPEG -> a canvas
    if (/\.sixel$/i.test(name) || (bytes[0] === 27 && bytes[1] === 80) || bytes[0] === 0x90) {
      var c = decodeSixel(bytes);
      return c ? Promise.resolve(c) : Promise.reject(new Error('not a sixel picture'));
    }
    return new Promise(function (ok, bad) {
      var im = new Image(), url = URL.createObjectURL(new Blob([bytes]));
      im.onload = function () {
        var c = document.createElement('canvas');
        c.width = im.naturalWidth; c.height = im.naturalHeight;
        c.getContext('2d').drawImage(im, 0, 0);
        URL.revokeObjectURL(url);
        ok(c);
      };
      im.onerror = function () { URL.revokeObjectURL(url); bad(new Error('not a picture this can read')); };
      im.src = url;
    });
  }

  // ---- pictures into the drawing, in half-blocks (two pixels a cell)
  function cellOf(top, bot) { // the character and colours for two half-pixels
    if (top === bot) return [219, top, canBg(top) ? top : 0];
    if (canBg(bot)) return [223, top, bot];
    if (canBg(top)) return [220, bot, top];
    return [223, top, bot & 7];
  }
  function pictureClip(src, cols, how) { // how: true (true colour), 'dither' or '' (16 colours)
    var trueColour = how === true;
    var w = cols, h = Math.max(2, Math.round(src.height * cols / src.width));
    if (h & 1) h++;
    h = Math.min(h, MAXROWS * 2);
    var c = document.createElement('canvas');
    c.width = w; c.height = h;
    var x2 = c.getContext('2d');
    x2.fillStyle = '#000'; x2.fillRect(0, 0, w, h);
    x2.imageSmoothingEnabled = true; x2.imageSmoothingQuality = 'high';
    x2.drawImage(src, 0, 0, w, h);
    var d = x2.getImageData(0, 0, w, h).data, q16 = null;
    if (how === 'dither') { // Floyd-Steinberg to the 16 colours
      var e = new Float32Array(w * h * 3);
      for (var k = 0; k < w * h; k++) { e[k * 3] = d[k * 4]; e[k * 3 + 1] = d[k * 4 + 1]; e[k * 3 + 2] = d[k * 4 + 2]; }
      q16 = new Int8Array(w * h);
      for (var yy = 0; yy < h; yy++) for (var xx = 0; xx < w; xx++) {
        var o3 = (yy * w + xx) * 3, r = Math.max(0, Math.min(255, e[o3])), g = Math.max(0, Math.min(255, e[o3 + 1])), bb = Math.max(0, Math.min(255, e[o3 + 2]));
        var n = nearest(Math.round(r) << 16 | Math.round(g) << 8 | Math.round(bb)), pc = PAL[n];
        q16[yy * w + xx] = n;
        var er = [r - (pc >> 16 & 255), g - (pc >> 8 & 255), bb - (pc & 255)];
        [[1, 0, 7], [-1, 1, 3], [0, 1, 5], [1, 1, 1]].forEach(function (t) {
          var x3 = xx + t[0], y3 = yy + t[1];
          if (x3 < 0 || x3 >= w || y3 >= h) return;
          var o4 = (y3 * w + x3) * 3;
          for (var cc = 0; cc < 3; cc++) e[o4 + cc] += er[cc] * t[2] / 16;
        });
      }
    }
    var col = function (x, y) {
      if (q16) return q16[y * w + x];
      var o = (y * w + x) * 4, rgb = d[o] << 16 | d[o + 1] << 8 | d[o + 2];
      return trueColour ? CUSTOM | rgb : nearest(rgb);
    };
    var clip0 = { w: w, h: h / 2, ch: [], fg: [], bg: [] };
    for (var y = 0; y < h / 2; y++) for (var x = 0; x < w; x++) {
      var cell = cellOf(col(x, 2 * y), col(x, 2 * y + 1));
      clip0.ch.push(cell[0]); clip0.fg.push(cell[1]); clip0.bg.push(cell[2]);
    }
    return clip0;
  }

  // ---- the host: the BBS's text folder or godrawr's files
  function q(o) { return Object.keys(o).map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(o[k] == null ? '' : o[k]); }).join('&'); }
  function apiList(dir, find) {
    return fetch(API + '/list?' + q({ dir: dir, find: find || '', token: TOKEN }), { credentials: 'same-origin' }).then(function (r) {
      if (!r.ok) return r.text().then(function (t) { throw new Error(t || r.status); });
      return r.json();
    });
  }
  function apiRead(dir, name) {
    return fetch(API + '/file?' + q({ dir: dir, name: name, token: TOKEN }), { credentials: 'same-origin' }).then(function (r) {
      if (!r.ok) return r.text().then(function (t) { throw new Error(t || r.status); });
      return r.arrayBuffer();
    }).then(function (b) { return new Uint8Array(b); });
  }
  function apiPost(what, fields) {
    var fd = new FormData();
    Object.keys(fields).forEach(function (k) { fd.append(k, fields[k]); });
    fd.append('csrf', TOKEN);
    return fetch(API + '/' + what, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) {
      return r.text().then(function (t) { if (!r.ok) throw new Error(t || r.status); return t; });
    });
  }
  function b64(arr) {
    var s = '';
    for (var i = 0; i < arr.length; i += 0x8000) s += String.fromCharCode.apply(null, arr.slice(i, i + 0x8000));
    return btoa(s);
  }

  // ---- file kinds
  var KINDS = {
    ans: { label: 'ANSI, 16 colours', pat: /\.(ans|an[1-9]|avt)$/i },
    ansi: { label: 'ANSI, high colour', pat: /\.ansi[1-9]?$/i },
    asc: { label: 'Pipe codes', pat: /\.(asc|msg)$/i },
    sixel: { label: 'Sixel picture', pat: /\.sixel$/i },
    pic: { label: 'Picture', pat: /\.(png|gif|jpe?g)$/i },
    text: { label: 'Text', pat: /\.(txt|nfo|diz)$/i }
  };
  function kindOf(name) { for (var k in KINDS) if (KINDS[k].pat.test(name)) return k; return ''; }
  function extOf(name) { var m = /\.([A-Za-z0-9]+)$/.exec(name); return m ? m[1].toLowerCase() : ''; }
  function baseOf(name) { return name.replace(/\.[A-Za-z0-9]+$/, ''); }
  var OPEN_FILTERS = [
    { label: 'Screens and pictures', kinds: ['ans', 'ansi', 'asc', 'sixel', 'pic', 'text'] },
    { label: 'ANSI screens (*.ANS, *.ANSI)', kinds: ['ans', 'ansi'] },
    { label: 'Pipe codes (*.ASC, *.MSG)', kinds: ['asc'] },
    { label: 'Sixel pictures (*.SIXEL)', kinds: ['sixel'] },
    { label: 'Pictures (*.PNG, *.GIF, *.JPG)', kinds: ['pic'] },
    { label: 'All files (*.*)', kinds: null }
  ];
  var PIC_FILTERS = [
    { label: 'Sixels and pictures', kinds: ['sixel', 'pic'] },
    { label: 'Sixel pictures (*.SIXEL)', kinds: ['sixel'] },
    { label: 'Pictures (*.PNG, *.GIF, *.JPG)', kinds: ['pic'] },
    { label: 'All files (*.*)', kinds: null }
  ];
  var SAVE_TYPES = [
    { ext: 'ans', label: 'ANSI, 16 colours (*.ANS)' },
    { ext: 'ansi', label: 'ANSI, high colour (*.ANSI)' },
    { ext: 'asc', label: 'Pipe codes (*.ASC)' },
    { ext: 'sixel', label: 'Sixel picture of the drawing (*.SIXEL)' }
  ];
  var EXPORT_TYPES = APP ? [
    { ext: 'sixel', label: 'Sixel, BBS size (at most ' + MAXW + '\u00d7' + MAXH + ')' },
    { ext: 'sixel', label: 'Sixel, full size (8\u00d716 pixels a cell)', full: true }
  ] : [{ ext: 'sixel', label: 'Sixel picture (at most ' + MAXW + '\u00d7' + MAXH + ')' }];
  var SAVE_EXT = /^(ans|ansi[1-9]?|asc|msg|avt|sixel)$/i;
  var BBS_NAME = /^[A-Za-z0-9_\-@]{1,24}$/;

  // ---- the file being edited
  var doc = { dir: '', name: '', ext: '', local: false };
  var lastDir = null;
  function fileUI() {
    var n = doc.name ? (doc.name + (doc.ext ? '.' + doc.ext : '')).toUpperCase() : 'Untitled';
    if (APP && doc.name) n = doc.name + (doc.ext ? '.' + (doc.name === doc.name.toUpperCase() ? doc.ext.toUpperCase() : doc.ext) : '');
    $('ae-filename').textContent = n + (doc.imported ? ' (imported)' : doc.local ? ' (from your computer)' : '');
    $('ae-filename').title = APP && doc.dir ? doc.dir : '';
    $('ae-dirty').hidden = !changed;
    if (APP) document.title = (changed ? '* ' : '') + n + ' - godrawr';
  }
  function setClean() { changed = false; fileUI(); }
  function okToDrop(what) { return !changed || confirm('The drawing has changes that aren’t saved. ' + what + ' anyway?'); }

  // ---- the dialogs
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  var modalOpen = false;
  function modal(title, wide) {
    var back = el('div', 'ae-modal'), box = el('div', 'ae-dlg' + (wide ? ' ae-wide' : ''));
    box.setAttribute('role', 'dialog');
    var bar = el('div', 'ae-dlg-title'), t = el('span', '', title), x = el('button', 'ae-x', '×');
    x.type = 'button'; x.title = 'Close (Esc)';
    bar.appendChild(t); bar.appendChild(x);
    box.appendChild(bar); back.appendChild(box);
    root.appendChild(back);
    modalOpen = true;
    var m = { back: back, box: box, title: t, onclose: null };
    m.close = function (v) { if (!back.parentNode) return; back.remove(); modalOpen = false; stage.focus(); if (m.onclose) m.onclose(v); };
    x.addEventListener('click', function () { m.close(null); });
    back.addEventListener('mousedown', function (e) { if (e.target === back) m.close(null); });
    box.addEventListener('keydown', function (e) { if (e.key === 'Escape') { e.preventDefault(); m.close(null); } e.stopPropagation(); });
    return m;
  }
  function fsize(n) { return n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : (n / 1048576).toFixed(1) + ' MB'; }
  function when(t) { if (!t) return ''; var d = new Date(t * 1000); return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2) + ' ' + ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2); }
  function wildRe(s) {
    s = s.trim();
    if (!s) return null;
    var r = s.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/\?/g, '.');
    return new RegExp(/[*?]/.test(s) ? '^' + r + '$' : r, 'i');
  }

  // fileDialog: Open or Save As.  opt: {save, title, filters | types, name, type}
  // -> a promise of {dir, name} (the name with its extension), {file} (from
  // the caller's own computer) or null.
  function fileDialog(opt) {
    return new Promise(function (resolve) {
      var m = modal(opt.title, true);
      var cache = {}, list = null, sortBy = 'name', sortUp = true, chosen = null, dir = lastDir != null ? lastDir : (doc.local ? '' : doc.dir || '');
      var path = el('div', 'ae-dlg-path');
      var up = el('button', 'ghost', '↑ Up'); up.type = 'button'; up.title = 'The folder above (Backspace)';
      var where = el('input', 'ae-dlg-where'); where.title = APP ? 'Type a folder and press Enter' : '';
      where.readOnly = !APP; where.spellcheck = false;
      var roots = el('select', 'ae-dlg-roots'); roots.title = 'Drives and places';
      var find = el('input', 'ae-dlg-find'); find.placeholder = 'Search (name, * and ?)'; find.type = 'search';
      var deep = el('label', 'ae-dlg-deep'), deepCb = el('input'); deepCb.type = 'checkbox';
      deep.appendChild(deepCb); deep.appendChild(document.createTextNode(' in subfolders'));
      path.appendChild(up); path.appendChild(where);
      if (APP) path.appendChild(roots);
      path.appendChild(find); path.appendChild(deep);
      var body = el('div', 'ae-dlg-body');
      var lwrap = el('div', 'ae-dlg-list'), table = el('table'), thead = el('thead'), tbody = el('tbody');
      var hr = el('tr');
      [['name', 'Name'], ['type', 'Type'], ['size', 'Size'], ['mod', 'Modified']].forEach(function (h) {
        var th = el('th', '', h[1]); th.dataset.k = h[0];
        th.addEventListener('click', function () { if (sortBy === h[0]) sortUp = !sortUp; else { sortBy = h[0]; sortUp = true; } draw(); });
        hr.appendChild(th);
      });
      thead.appendChild(hr); table.appendChild(thead); table.appendChild(tbody); lwrap.appendChild(table);
      var prev = el('div', 'ae-dlg-preview'), pbox = el('div', 'ae-dlg-pbox'), pinfo = el('div', 'small dim ae-dlg-pinfo', 'Click a file to see it here.');
      prev.appendChild(pbox); prev.appendChild(pinfo);
      body.appendChild(lwrap); body.appendChild(prev);
      var foot = el('div', 'ae-dlg-foot');
      var nlab = el('label', '', 'File name '), fname = el('input', 'ae-dlg-name'); fname.spellcheck = false;
      nlab.appendChild(fname);
      var tsel = el('select', 'ae-dlg-type');
      (opt.save ? opt.types : opt.filters).forEach(function (t, i) { var o = el('option', '', t.label); o.value = i; tsel.appendChild(o); });
      if (opt.save) tsel.value = Math.max(0, opt.types.map(function (t) { return t.ext; }).indexOf(opt.type));
      var fromPC = null;
      if (!APP) {
        fromPC = el('button', 'ghost', opt.save ? 'To my computer…' : 'From my computer…'); fromPC.type = 'button';
        fromPC.title = opt.save ? 'Download it to your own computer instead' : 'Open a file of your own computer (your computer’s Open dialog)';
      }
      var okb = el('button', '', opt.save ? 'Save' : 'Open'); okb.type = 'button';
      var cancel = el('button', 'ghost', 'Cancel'); cancel.type = 'button';
      foot.appendChild(nlab); foot.appendChild(tsel);
      var sp = el('span', 'ae-dlg-spacer'); foot.appendChild(sp);
      if (fromPC) foot.appendChild(fromPC);
      foot.appendChild(okb); foot.appendChild(cancel);
      var note = el('div', 'ae-dlg-note small dim');
      note.textContent = opt.save ? (APP ? 'Type a name; its extension picks the kind (NAME.ANSI3 is variant 3), else the kind below.' :
        'Saved in the BBS’s text folder. Names are letters, digits, _ and - (up to 24); NAME.ANSI1 to NAME.ANSI9 are random variants.') :
        'Double-click a file (or pick it and press Open). Folders open with a double-click.';
      m.box.appendChild(path); m.box.appendChild(body); m.box.appendChild(foot); m.box.appendChild(note);
      if (opt.name) fname.value = opt.name;
      m.onclose = function (v) { resolve(v || null); };

      function kindsNow() { return opt.save ? null : opt.filters[tsel.value].kinds; }
      function shown() {
        if (!list) return [];
        var re = wildRe(find.value), ks = kindsNow(), out = [];
        if (!deepCb.checked || !find.value.trim()) list.dirs.forEach(function (d) { if (!re || re.test(d)) out.push({ dir: true, name: d }); });
        list.files.forEach(function (f) {
          var k = kindOf(f.name);
          if (opt.save) { if (!/^(ans|ansi|asc|sixel)$/.test(k)) return; }
          else if (ks && ks.indexOf(k) < 0) return;
          if (re && !re.test(f.path || f.name)) return;
          out.push({ name: f.name, path: f.path, at: f.dir, size: f.size, mod: f.mod, kind: k });
        });
        out.sort(function (a, b) {
          if (a.dir !== b.dir) return a.dir ? -1 : 1;
          var x = sortBy === 'size' ? (a.size || 0) - (b.size || 0) : sortBy === 'mod' ? (a.mod || 0) - (b.mod || 0) :
            sortBy === 'type' ? (KINDS[a.kind] ? KINDS[a.kind].label : '').localeCompare(KINDS[b.kind] ? KINDS[b.kind].label : '') :
            (a.path || a.name).toUpperCase() < (b.path || b.name).toUpperCase() ? -1 : (a.path || a.name).toUpperCase() > (b.path || b.name).toUpperCase() ? 1 : 0;
          return sortUp ? x : -x;
        });
        return out;
      }
      var rowsNow = [], cur = -1;
      function draw() {
        rowsNow = shown();
        tbody.textContent = '';
        Array.prototype.forEach.call(hr.children, function (th) { th.className = th.dataset.k === sortBy ? (sortUp ? 'up' : 'down') : ''; });
        if (!rowsNow.length) {
          var tr0 = el('tr'), td0 = el('td', 'dim', list ? (find.value ? 'Nothing matches.' : 'No files of this kind here.') : 'Loading…'); td0.colSpan = 4;
          tr0.appendChild(td0); tbody.appendChild(tr0);
        }
        rowsNow.forEach(function (r, i) {
          var tr = el('tr', r.dir ? 'dir' : '');
          tr.appendChild(el('td', 'nm', (r.dir ? '📁 ' : '') + (r.path || r.name)));
          tr.appendChild(el('td', '', r.dir ? 'Folder' : KINDS[r.kind] ? KINDS[r.kind].label : (extOf(r.name).toUpperCase() + ' file')));
          tr.appendChild(el('td', 'num', r.dir ? '' : fsize(r.size)));
          tr.appendChild(el('td', '', when(r.mod)));
          tr.addEventListener('click', function () { choose(i); });
          tr.addEventListener('dblclick', function () { choose(i); go(); });
          tbody.appendChild(tr);
        });
        cur = -1;
      }
      function choose(i) {
        cur = i;
        Array.prototype.forEach.call(tbody.children, function (tr, k) { tr.classList.toggle('on', k === i); });
        var r = rowsNow[i];
        if (!r) return;
        if (tbody.children[i]) tbody.children[i].scrollIntoView({ block: 'nearest' });
        if (r.dir) { chosen = null; return; }
        chosen = r;
        fname.value = opt.save ? r.name : (r.path || r.name);
        preview(r);
      }
      var seq = 0;
      function preview(r) {
        var my = ++seq, at = r.at != null ? r.at : list.dir;
        pbox.textContent = ''; pinfo.textContent = 'Loading ' + r.name + '…';
        var key = at + '|' + r.name;
        (cache[key] ? Promise.resolve(cache[key]) : apiRead(at, r.name).then(function (b) { cache[key] = b; return b; })).then(function (b) {
          if (my !== seq) return;
          if (r.kind === 'sixel' || r.kind === 'pic') {
            return pictureCanvas(b, r.name).then(function (c) {
              if (my !== seq) return;
              pbox.appendChild(c);
              pinfo.textContent = r.name + ': ' + c.width + '×' + c.height + ' pixels' + (c.colours ? ', ' + c.colours + ' colours' : '') + ', ' + fsize(b.length);
            });
          }
          if (b.length > 4 << 20) { pinfo.textContent = r.name + ': ' + fsize(b.length) + ' (too big to preview)'; return; }
          var d = parseScreen(b), c = docCanvas(d, 60);
          pbox.appendChild(c);
          var hi = 0; for (var k = 0; k < d.rows * COLS; k++) if (isCustom(d.fg[k]) || isCustom(d.bg[k])) { hi = 1; break; }
          pinfo.textContent = r.name + ': ' + d.rows + ' rows' + (hi ? ', high colour' : '') + ', ' + fsize(b.length);
        }).catch(function (e) { if (my === seq) pinfo.textContent = r.name + ': ' + e.message; });
      }
      function load(d) {
        list = null; draw();
        var f = deepCb.checked ? find.value.trim() : '';
        apiList(d, f).then(function (l) {
          list = l; dir = l.dir; where.value = APP ? l.dir : (l.dir ? 'text folder › ' + l.dir : 'BBS text folder');
          where.scrollLeft = where.scrollWidth;
          up.disabled = l.parent == null;
          if (APP && l.roots) {
            roots.textContent = '';
            var o0 = el('option', '', 'Places…'); o0.value = ''; roots.appendChild(o0);
            l.roots.forEach(function (r) { var o = el('option', '', r.label || r.path); o.value = r.path; roots.appendChild(o); });
          }
          if (l.note) pinfo.textContent = l.note;
          draw();
          var want = fname.value.toUpperCase();
          rowsNow.forEach(function (r, i) { if (!r.dir && (r.path || r.name).toUpperCase() === want) choose(i); });
        }).catch(function (e) { list = { dir: d, dirs: [], files: [] }; draw(); pinfo.textContent = 'Can’t read that folder: ' + e.message; });
      }
      function go() {
        var r = cur >= 0 ? rowsNow[cur] : null;
        if (r && r.dir && (!opt.save || !fname.value.trim() || fname.value === r.name)) { load(sub(list.dir, r.name)); return; }
        var typed = fname.value.trim();
        if (!opt.save) {
          if (chosen && (chosen.path || chosen.name) === typed) { done({ dir: chosen.at != null ? chosen.at : list.dir, name: chosen.name }); return; }
          if (!typed) return;
          // a typed name: a file here, or (godrawr) a path
          var hit = list && list.files.filter(function (f) { return (f.path || f.name).toUpperCase() === typed.toUpperCase(); })[0];
          if (hit) { done({ dir: hit.dir != null ? hit.dir : list.dir, name: hit.name }); return; }
          if (APP && /[\/\\]/.test(typed)) { var cut = Math.max(typed.lastIndexOf('/'), typed.lastIndexOf('\\')); done({ dir: typed.slice(0, cut + 1) || '/', name: typed.slice(cut + 1) }); return; }
          pinfo.textContent = 'There’s no ' + typed + ' here.';
          return;
        }
        // Save As: the name, the kind
        var t = opt.types[tsel.value], ext = extOf(typed), base = typed;
        if (ext && SAVE_EXT.test(ext)) base = baseOf(typed); else ext = t.ext;
        if (!base) { fname.focus(); return; }
        if (!APP && !BBS_NAME.test(base)) { pinfo.textContent = 'A screen name is letters, digits, _ and - (up to 24), no spaces.'; fname.focus(); return; }
        if (APP && /[\/\\:*?"<>|]/.test(base)) { pinfo.textContent = 'A file name can’t have / \\ : * ? " < > |'; fname.focus(); return; }
        var full = base + '.' + (APP ? ext : ext.toUpperCase());
        if (!APP) full = full.toUpperCase();
        var exists = list && list.files.some(function (f) { return f.name.toUpperCase() === full.toUpperCase(); });
        if (exists && !confirm(full + ' is there already. Replace it?')) return;
        done({ dir: list ? list.dir : dir, name: base, ext: ext, full: !!t.full });
      }
      function done(v) { lastDir = v.dir; m.close(v); }
      function sub(d, n) { if (!APP) return d ? d + '/' + n : n; var s = /\\/.test(d) && !/\//.test(d) ? '\\' : '/'; return d.replace(/[\/\\]$/, '') + s + n; }
      up.addEventListener('click', function () { if (list && list.parent != null) load(list.parent); });
      where.addEventListener('keydown', function (e) { if (e.key === 'Enter' && APP) { e.preventDefault(); load(where.value.trim()); } });
      roots.addEventListener('change', function () { if (roots.value) load(roots.value); });
      var ft = null;
      find.addEventListener('input', function () { if (deepCb.checked) { clearTimeout(ft); ft = setTimeout(function () { load(dir); }, 350); } else draw(); });
      deepCb.addEventListener('change', function () { if (find.value.trim()) load(dir); });
      tsel.addEventListener('change', function () {
        if (opt.save) { var t = opt.types[tsel.value], v = fname.value.trim(); if (v) fname.value = (extOf(v) && SAVE_EXT.test(extOf(v)) ? baseOf(v) : v) + '.' + (APP ? t.ext : t.ext.toUpperCase()); }
        else draw();
      });
      fname.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); go(); } });
      okb.addEventListener('click', go);
      cancel.addEventListener('click', function () { m.close(null); });
      m.box.addEventListener('keydown', function (e) {
        if (e.target === fname || e.target === where || e.target === find) {
          if (e.key === 'ArrowDown' && e.target === find && rowsNow.length) { e.preventDefault(); lwrap.focus(); choose(0); }
          return;
        }
        if (e.key === 'ArrowDown') { e.preventDefault(); choose(Math.min(rowsNow.length - 1, cur + 1)); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); choose(Math.max(0, cur - 1)); }
        else if (e.key === 'Enter') { e.preventDefault(); go(); }
        else if (e.key === 'Backspace' && list && list.parent != null) { e.preventDefault(); load(list.parent); }
      });
      lwrap.tabIndex = 0;
      if (fromPC) fromPC.addEventListener('click', function () {
        if (opt.save) {
          var t = opt.types[tsel.value], typed = fname.value.trim(), ext = extOf(typed);
          var base = ext && SAVE_EXT.test(ext) ? baseOf(typed) : typed || doc.name || 'UNTITLED';
          if (!(ext && SAVE_EXT.test(ext))) ext = t.ext;
          m.close({ download: true, name: base, ext: ext });
          return;
        }
        var inp = el('input'); inp.type = 'file';
        inp.accept = '.ans,.ansi,.asc,.msg,.avt,.txt,.nfo,.diz,.an1,.an2,.an3,.an4,.an5,.an6,.an7,.an8,.an9,.sixel,.png,.gif,.jpg,.jpeg,image/*';
        inp.addEventListener('change', function () { if (inp.files[0]) m.close({ file: inp.files[0] }); });
        inp.click();
      });
      draw();
      load(dir);
      setTimeout(function () { (opt.save ? fname : find).focus(); if (opt.save) fname.select(); }, 0);
    });
  }

  // ---- the sixel viewer: zoom, import into the drawing, save as .SIXEL
  function viewer(canvasPic, name, bytes) {
    var m = modal('Sixel Viewer — ' + name, true);
    var bar = el('div', 'ae-dlg-path ae-view-bar');
    var zl = el('label', '', 'Zoom '), zs = el('select');
    [['fit', 'Fit'], ['1', '1x'], ['2', '2x'], ['3', '3x'], ['4', '4x']].forEach(function (z) { var o = el('option', '', z[1]); o.value = z[0]; zs.appendChild(o); });
    zl.appendChild(zs); bar.appendChild(zl);
    var info = el('span', 'small dim', canvasPic.width + '×' + canvasPic.height + ' pixels' + (canvasPic.colours ? ', ' + canvasPic.colours + ' colours' : '') + (bytes ? ', ' + fsize(bytes.length) : ''));
    bar.appendChild(info);
    var area = el('div', 'ae-view-area');
    canvasPic.className = 'ae-view-pic';
    area.appendChild(canvasPic);
    var foot = el('div', 'ae-dlg-foot');
    var cl = el('label', '', 'Import '), cols = el('select');
    [80, 64, 40, 32, 20].forEach(function (n) { var o = el('option', '', n + ' columns wide'); o.value = n; cols.appendChild(o); });
    cl.appendChild(cols);
    var cm = el('select');
    [['dither', 'in the 16 colours, dithered (.ANS)'], ['16', 'in the 16 colours, flat (.ANS)'], ['true', 'in true colour (.ANSI)']].forEach(function (c) { var o = el('option', '', c[1]); o.value = c[0]; cm.appendChild(o); });
    var asNew = el('button', '', 'Import as a New Screen'); asNew.type = 'button';
    asNew.title = 'The picture becomes the drawing, in half-blocks (two pixels a cell)';
    var asPaste = el('button', 'ghost', 'Paste into the Drawing'); asPaste.type = 'button';
    asPaste.title = 'Then click where it goes in the drawing';
    var toSixel = null;
    if (!/\.sixel$/i.test(name)) { toSixel = el('button', 'ghost', 'Save as .SIXEL…'); toSixel.type = 'button'; toSixel.title = 'Save this picture as a sixel (NAME.SIXEL)'; }
    var close = el('button', 'ghost', 'Close'); close.type = 'button';
    foot.appendChild(cl); foot.appendChild(cm);
    foot.appendChild(el('span', 'ae-dlg-spacer'));
    foot.appendChild(asNew); foot.appendChild(asPaste);
    if (toSixel) foot.appendChild(toSixel);
    foot.appendChild(close);
    m.box.appendChild(bar); m.box.appendChild(area); m.box.appendChild(foot);
    function zoomTo() {
      var z = zs.value;
      if (z === 'fit') {
        var s = Math.min((area.clientWidth - 8) / canvasPic.width, (area.clientHeight - 8) / canvasPic.height);
        if (s > 1) s = Math.floor(s); // small pictures: a whole number of times, sharp
        canvasPic.style.width = Math.max(16, Math.floor(canvasPic.width * Math.max(s, 0.05))) + 'px';
      } else canvasPic.style.width = canvasPic.width * parseInt(z, 10) + 'px';
    }
    zs.addEventListener('change', zoomTo);
    setTimeout(zoomTo, 0);
    function clip0() { return pictureClip(canvasPic, parseInt(cols.value, 10), cm.value === 'true' ? true : cm.value === 'dither' ? 'dither' : ''); }
    asNew.addEventListener('click', function () {
      if (!okToDrop('Replace the drawing with the picture')) return;
      var c = clip0(), d = { rows: Math.max(25, c.h), ch: new Uint8Array(COLS * Math.max(25, c.h)).fill(32), fg: new Int32Array(COLS * Math.max(25, c.h)).fill(7), bg: new Int32Array(COLS * Math.max(25, c.h)) };
      for (var y = 0; y < c.h; y++) for (var x = 0; x < c.w; x++) { var k = y * c.w + x, o = y * COLS + x; d.ch[o] = c.ch[k]; d.fg[o] = c.fg[k]; d.bg[o] = c.bg[k]; }
      m.close();
      loadDoc(d);
      doc = { dir: doc.dir, name: baseOf(name).toUpperCase().replace(/[^A-Z0-9_\-@]/g, '_').slice(0, 24), ext: cm.value === 'true' ? 'ansi' : 'ans', local: true, imported: true };
      changed = true; fileUI();
      msg('Imported ' + name + ': ' + c.w + '×' + c.h + ' cells. Save As to keep it.');
    });
    asPaste.addEventListener('click', function () {
      clip = clip0(); m.close();
      paste();
    });
    if (toSixel) toSixel.addEventListener('click', function () {
      fileDialog({ save: true, title: 'Save the Picture as a Sixel', types: [{ ext: 'sixel', label: 'Sixel picture (*.SIXEL)' }], type: 'sixel', name: baseOf(name).toUpperCase().slice(0, 24) + '.SIXEL' }).then(function (t) {
        if (!t || t.download) { if (t) msg('Save it in a folder (Download isn’t for sixels).'); return; }
        var fields = { dir: t.dir, name: t.name };
        if (bytes) fields.picture = new Blob([bytes]); else fields.png = canvasPic.toDataURL('image/png');
        apiPost('sixel', fields).then(function (r) { msg(r); }).catch(function (e) { msg('Not saved: ' + e.message); });
      });
    });
    close.addEventListener('click', function () { m.close(); });
  }

  // ---- open, save, save as
  function readLocal(f) { return f.arrayBuffer().then(function (b) { return new Uint8Array(b); }); }
  function openBytes(b, name, from) {
    var k = kindOf(name);
    if (k === 'sixel' || k === 'pic' || (b[0] === 27 && b[1] === 80) || b[0] === 0x90) {
      return pictureCanvas(b, name).then(function (c) { viewer(c, name, b); msg('Viewing ' + name + '.'); });
    }
    if (!okToDrop('Open ' + name)) return Promise.resolve();
    loadDoc(parseScreen(b));
    var ext = extOf(name);
    doc = { dir: from.dir, name: baseOf(name), ext: SAVE_EXT.test(ext) ? ext : '', local: !!from.local };
    if (!APP) doc.name = doc.name.toUpperCase();
    fileUI();
    msg('Opened ' + name + '.');
    return Promise.resolve();
  }
  function openDialog(filters, title) {
    if (modalOpen) return;
    fileDialog({ title: title || 'Open', filters: filters || OPEN_FILTERS }).then(function (r) {
      if (!r) return;
      if (r.file) return readLocal(r.file).then(function (b) { return openBytes(b, r.file.name, { local: true, dir: '' }); });
      return apiRead(r.dir, r.name).then(function (b) { return openBytes(b, r.name, { dir: r.dir }); });
    }).catch(function (e) { msg('Not opened: ' + e.message); });
  }
  function encodeAs(ext) {
    if (/^ansi/.test(ext)) return encodeANSI(true);
    if (ext === 'asc' || ext === 'msg') return encodeASC();
    return encodeANSI(false);
  }
  function drawingPNG() {
    var c = document.createElement('canvas'), h = usedRows() * CH;
    c.width = cv.width; c.height = h;
    c.getContext('2d').drawImage(cv, 0, 0, cv.width, h, 0, 0, cv.width, h);
    return c.toDataURL('image/png');
  }
  function saveTo(t) {
    var ext = t.ext.toLowerCase();
    if ((ext === 'ans' || ext === 'avt') && customCount() && !confirm(customCount() + ' cell(s) are in true colour: in .' + ext.toUpperCase() + ' they become the nearest of the 16 colours. Save anyway?')) return;
    if (t.download) {
      var data = ext === 'sixel' ? null : encodeAs(ext);
      if (!data) { msg('A sixel is made by the ' + (APP ? 'program' : 'BBS') + ': save it in a folder.'); return; }
      var a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([new Uint8Array(data)], { type: 'application/octet-stream' }));
      a.download = (t.name + '.' + ext).toUpperCase();
      document.body.appendChild(a); a.click(); a.remove();
      msg('Downloaded ' + a.download + '.');
      return;
    }
    var p = ext === 'sixel' ? apiPost('sixel', { dir: t.dir, name: t.name, png: drawingPNG(), full: t.full ? '1' : '' }) :
      apiPost('save', { dir: t.dir, name: t.name, ext: ext, data: b64(encodeAs(ext)) });
    p.then(function (r) {
      msg(r);
      if (ext !== 'sixel') { doc = { dir: t.dir, name: t.name, ext: ext, local: false }; setClean(); }
    }).catch(function (e) { msg('Not saved: ' + e.message); });
  }
  function saveAs() {
    if (modalOpen) return;
    var type = doc.ext && /^(ans|ansi|asc)/.test(doc.ext) ? doc.ext.replace(/\d$/, '') : (customCount() ? 'ansi' : 'ans');
    var nm = doc.name ? doc.name + '.' + (doc.ext || type) : 'UNTITLED.' + type;
    fileDialog({ save: true, title: 'Save As', types: SAVE_TYPES, type: type, name: APP ? nm : nm.toUpperCase() }).then(function (t) { if (t) saveTo(t); });
  }
  function save() {
    if (doc.name && doc.ext && !doc.local && SAVE_EXT.test(doc.ext) && doc.ext !== 'sixel') saveTo({ dir: doc.dir, name: doc.name, ext: doc.ext });
    else saveAs();
  }
  $('ae-open').addEventListener('click', function () { openDialog(); });
  $('ae-save').addEventListener('click', save);
  $('ae-saveas').addEventListener('click', saveAs);
  $('ae-import').addEventListener('click', function () { openDialog(PIC_FILTERS, 'Import a Picture (sixel, PNG, GIF, JPEG)'); });
  $('ae-view').addEventListener('click', function () { openDialog(PIC_FILTERS, 'Sixel Viewer: Open a Picture'); });
  $('ae-export').addEventListener('click', function () {
    if (modalOpen) return;
    fileDialog({ save: true, title: 'Export the Drawing as a Sixel', types: EXPORT_TYPES, type: 'sixel', name: (doc.name || 'UNTITLED') + (APP ? '.sixel' : '.SIXEL') }).then(function (t) {
      if (!t) return;
      if (t.download) { msg('A sixel is made by the ' + (APP ? 'program' : 'BBS') + ': save it in a folder.'); return; }
      t.ext = 'sixel';
      saveTo(t);
    });
  });
  $('ae-new').addEventListener('click', function () {
    if (!okToDrop('Start a new screen')) return;
    chA = null; alloc(25); cx = cy = 0; undoS = []; redoS = []; sel = null; floating = null;
    doc = { dir: doc.dir, name: '', ext: '', local: false };
    setClean(); msg('');
  });
  window.addEventListener('keydown', function (e) {
    if (modalOpen || !(e.ctrlKey || e.metaKey) || e.altKey) return;
    var k = e.key.toLowerCase();
    if (k === 'o') { e.preventDefault(); openDialog(); }
    else if (k === 's' && e.shiftKey) { e.preventDefault(); saveAs(); }
    else if (k === 's') { e.preventDefault(); save(); }
  });
  // drop a file on the drawing to open it
  stage.addEventListener('dragover', function (e) { e.preventDefault(); });
  stage.addEventListener('drop', function (e) {
    e.preventDefault();
    var f = e.dataTransfer.files[0];
    if (f) readLocal(f).then(function (b) { return openBytes(b, f.name, { local: true, dir: '' }); }).catch(function (er) { msg('Not opened: ' + er.message); });
  });
  window.addEventListener('beforeunload', function (e) { if (changed) { e.preventDefault(); e.returnValue = ''; } });
  if (APP) setInterval(function () { fetch(API + '/ping?token=' + encodeURIComponent(TOKEN), { method: 'POST' }).catch(function () {}); }, 2000);

  stage.tabIndex = 0;
  fetch(root.getAttribute('data-static') + '/vga8x16.bin').then(function (r) { return r.arrayBuffer(); }).then(function (buf) {
    font = new Uint8Array(buf);
    alloc(25);
    fkeys();
    ui();
    selBar();
    fileUI();
    stage.focus();
    var start = root.getAttribute('data-open');
    if (start) {
      var cut = start.indexOf('|'), d = start.slice(0, cut), n = start.slice(cut + 1);
      apiRead(d, n).then(function (b) { return openBytes(b, n, { dir: d }); }).catch(function (e) { msg('Not opened: ' + e.message); });
    }
  });
  (function loop() {
    if (dirty && img) { ctx.putImageData(img, 0, 0); dirty = false; }
    requestAnimationFrame(loop);
  })();
})();
