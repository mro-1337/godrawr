module godrawr

go 1.21
