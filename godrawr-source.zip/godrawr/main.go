// godrawr is the ANSI drawing program of Illusion/X BBS on its own: the
// same editor as the BBS's web pages (internal/ansiedit), working on the
// files of the computer it runs on, in a window of its own (Edge, Chrome or
// Chromium in app mode).  Open and Save As dialogs with search and
// previews, .ANS / .ANSI / .ASC screens, a sixel viewer, pictures and
// sixels imported in half-blocks, the drawing saved as a sixel.
//
//	godrawr [-port N] [-nowindow] [-sixel WxH] [FILE]
package main

import (
	"bytes"
	"context"
	"crypto/rand"
	"crypto/subtle"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"html/template"
	"io/fs"
	"net"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"

	"godrawr/internal/ansiedit"
	"godrawr/internal/appwin"
	"godrawr/internal/sixel"
)

const progName = "godrawr"

var version = "1.0"

type app struct {
	token      string
	sixW, sixH int
	open       string // dir|name to open at start

	mu       sync.Mutex
	settings settings
	lastPing time.Time
}

// settings are kept in the user's config folder (godrawr/godrawr.json).
type settings struct {
	LastDir string `json:"lastdir"`
}

func configDir() string {
	d, err := os.UserConfigDir()
	if err != nil {
		d = os.TempDir()
	}
	return filepath.Join(d, progName)
}

func (a *app) load() {
	b, err := os.ReadFile(filepath.Join(configDir(), progName+".json"))
	if err == nil {
		json.Unmarshal(b, &a.settings)
	}
}

func (a *app) save() {
	a.mu.Lock()
	b, _ := json.MarshalIndent(a.settings, "", "  ")
	a.mu.Unlock()
	os.MkdirAll(configDir(), 0o755)
	os.WriteFile(filepath.Join(configDir(), progName+".json"), b, 0o644)
}

func main() {
	port := flag.Int("port", 0, "the local port for the window (0: any free one)")
	noWin := flag.Bool("nowindow", false, "don't open the window: print its address (open it in a browser yourself)")
	six := flag.String("sixel", "640x400", "the largest sixel a picture or the drawing is saved as (pixels, WxH)")
	ver := flag.Bool("version", false, "print the version")
	flag.Usage = func() {
		fmt.Fprintf(os.Stderr, "%s %s - the ANSI drawing program of Illusion/X BBS\n\nUsage: %s [switches] [FILE]\n\n", progName, version, progName)
		flag.PrintDefaults()
		fmt.Fprintf(os.Stderr, "\nFILE: a screen (.ANS, .ANSI, .ASC ...), a sixel or a picture to open.\n")
	}
	flag.Parse()
	if *ver {
		fmt.Println(progName, version)
		return
	}
	a := &app{sixW: 640, sixH: 400}
	if w, h, ok := strings.Cut(strings.ToLower(*six), "x"); ok {
		a.sixW, _ = strconv.Atoi(w)
		a.sixH, _ = strconv.Atoi(h)
		a.sixW, a.sixH = max(64, a.sixW), max(48, a.sixH)
	}
	tok := make([]byte, 16)
	rand.Read(tok)
	a.token = hex.EncodeToString(tok)
	a.load()
	if f := flag.Arg(0); f != "" {
		if abs, err := filepath.Abs(f); err == nil {
			if fi, err := os.Stat(abs); err == nil && fi.IsDir() {
				a.settings.LastDir = abs
			} else {
				a.open = filepath.Dir(abs) + "|" + filepath.Base(abs)
				a.settings.LastDir = filepath.Dir(abs)
			}
		}
	}

	ln, err := net.Listen("tcp", "127.0.0.1:"+strconv.Itoa(*port))
	if err != nil {
		fatal("Can't listen on 127.0.0.1:%d: %v", *port, err)
	}
	url := fmt.Sprintf("http://%s/?t=%s", ln.Addr(), a.token)
	srv := &http.Server{Handler: a.routes(), ReadHeaderTimeout: 10 * time.Second}
	go srv.Serve(ln)

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	if *noWin {
		fmt.Printf("%s %s: open %s in a browser (Ctrl-C ends it)\n", progName, version, url)
		<-ctx.Done()
	} else {
		appwin.Open(url, filepath.Join(configDir(), "window"), 1500, 960)
		a.watch(ctx) // ends when the window has gone
	}
	a.save()
	shut, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	srv.Shutdown(shut)
}

// watch waits for the window: it says it's there every 2 seconds; 12
// seconds without (or 2 minutes without it ever coming) and godrawr ends.
func (a *app) watch(ctx context.Context) {
	start := time.Now()
	t := time.NewTicker(time.Second)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
		a.mu.Lock()
		last := a.lastPing
		a.mu.Unlock()
		if last.IsZero() && time.Since(start) > 2*time.Minute || !last.IsZero() && time.Since(last) > 12*time.Second {
			return
		}
	}
}

func fatal(f string, args ...any) {
	fmt.Fprintf(os.Stderr, progName+": "+f+"\n", args...)
	os.Exit(1)
}

func (a *app) routes() http.Handler {
	mux := http.NewServeMux()
	mux.Handle("/static/", http.StripPrefix("/static/", ansiedit.Handler()))
	mux.HandleFunc("/", a.page)
	mux.HandleFunc("/api/", a.api)
	// only this computer, by its own name (a web page elsewhere can't
	// reach it through a name of its own: DNS rebinding)
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		host, _, _ := net.SplitHostPort(r.Host)
		if host != "127.0.0.1" && host != "localhost" {
			http.Error(w, "not here", http.StatusForbidden)
			return
		}
		w.Header().Set("X-Frame-Options", "DENY")
		mux.ServeHTTP(w, r)
	})
}

func (a *app) tokenOK(r *http.Request) bool {
	t := r.URL.Query().Get("token")
	if t == "" {
		t = r.URL.Query().Get("t")
	}
	if t == "" {
		t = r.FormValue("csrf")
	}
	return subtle.ConstantTimeCompare([]byte(t), []byte(a.token)) == 1
}

var pageTmpl = template.Must(template.New("p").Parse(`<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>godrawr</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="/static/app.css"></head>
<body><header class="gd-top"><span class="gd-name">godrawr</span><span class="gd-sub">ANSI drawing &middot; Illusion/X BBS</span><span class="gd-ver">{{.Version}}</span></header>
<main class="gd-main">{{.Editor}}</main></body></html>`))

func (a *app) page(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.NotFound(w, r)
		return
	}
	if !a.tokenOK(r) {
		http.Error(w, "Open godrawr from its own window.", http.StatusForbidden)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("Content-Security-Policy", "default-src 'self'; img-src 'self' blob: data:; style-src 'self' 'unsafe-inline'")
	pageTmpl.Execute(w, map[string]any{"Version": version, "Editor": ansiedit.Markup(ansiedit.Options{
		Mode: "app", API: "/api", Static: "/static", Token: a.token, MaxW: a.sixW, MaxH: a.sixH, Title: progName, Open: a.open})})
}

type entry struct {
	Name string  `json:"name"`
	Size int64   `json:"size"`
	Mod  int64   `json:"mod"`
	Path string  `json:"path,omitempty"`
	Dir  *string `json:"dir,omitempty"`
}

type place struct {
	Path  string `json:"path"`
	Label string `json:"label"`
}

func (a *app) api(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		r.Body = http.MaxBytesReader(w, r.Body, 64<<20)
		if err := r.ParseMultipartForm(64 << 20); err != nil && !errors.Is(err, http.ErrNotMultipart) {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
	}
	if !a.tokenOK(r) {
		http.Error(w, "not allowed", http.StatusForbidden)
		return
	}
	switch strings.TrimPrefix(r.URL.Path, "/api/") {
	case "ping":
		a.mu.Lock()
		a.lastPing = time.Now()
		a.mu.Unlock()
		w.WriteHeader(http.StatusNoContent)
	case "list":
		a.list(w, r)
	case "file":
		p, err := a.path(r.URL.Query().Get("dir"), r.URL.Query().Get("name"))
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		fi, err := os.Stat(p)
		if err != nil || fi.IsDir() {
			http.Error(w, "there's no such file", http.StatusNotFound)
			return
		}
		if fi.Size() > 64<<20 {
			http.Error(w, "too big (more than 64 MB)", http.StatusRequestEntityTooLarge)
			return
		}
		b, err := os.ReadFile(p)
		if err != nil {
			http.Error(w, err.Error(), http.StatusForbidden)
			return
		}
		w.Header().Set("Content-Type", "application/octet-stream")
		w.Header().Set("Cache-Control", "no-store")
		w.Write(b)
	case "save", "sixel":
		if r.Method != http.MethodPost {
			http.Error(w, "POST", http.StatusMethodNotAllowed)
			return
		}
		a.write(w, r)
	default:
		http.NotFound(w, r)
	}
}

// path is dir/name, checked: a plain name in an absolute folder.
func (a *app) path(dir, name string) (string, error) {
	if dir == "" || !filepath.IsAbs(dir) {
		return "", errors.New("which folder?")
	}
	if name == "" || name != filepath.Base(name) || name == "." || name == ".." || strings.ContainsAny(name, `/\`) {
		return "", errors.New("not a file name: " + name)
	}
	return filepath.Join(filepath.Clean(dir), name), nil
}

func (a *app) startDir() string {
	a.mu.Lock()
	d := a.settings.LastDir
	a.mu.Unlock()
	if fi, err := os.Stat(d); d != "" && err == nil && fi.IsDir() {
		return d
	}
	if h, err := os.UserHomeDir(); err == nil {
		for _, s := range []string{"Documents", ""} {
			if fi, err := os.Stat(filepath.Join(h, s)); err == nil && fi.IsDir() {
				return filepath.Join(h, s)
			}
		}
	}
	d, _ = os.Getwd()
	return d
}

// places are the drives (Windows) and the user's folders.
func places() []place {
	var out []place
	if runtime.GOOS == "windows" {
		for c := 'A'; c <= 'Z'; c++ {
			d := string(c) + `:\`
			if _, err := os.Stat(d); err == nil {
				out = append(out, place{d, "Drive " + string(c) + ":"})
			}
		}
	} else {
		out = append(out, place{"/", "/ (the root)"})
	}
	if h, err := os.UserHomeDir(); err == nil {
		out = append(out, place{h, "Home (" + filepath.Base(h) + ")"})
		for _, s := range []string{"Desktop", "Documents", "Pictures", "Downloads"} {
			if fi, err := os.Stat(filepath.Join(h, s)); err == nil && fi.IsDir() {
				out = append(out, place{filepath.Join(h, s), s})
			}
		}
	}
	return out
}

func hidden(name string) bool { return strings.HasPrefix(name, ".") || strings.HasPrefix(name, "$") }

func (a *app) list(w http.ResponseWriter, r *http.Request) {
	dir := strings.TrimSpace(r.URL.Query().Get("dir"))
	if dir == "" {
		dir = a.startDir()
	}
	if runtime.GOOS == "windows" && len(dir) == 2 && dir[1] == ':' {
		dir += `\`
	}
	if !filepath.IsAbs(dir) {
		http.Error(w, "a folder is a full path, e.g. "+a.startDir(), http.StatusBadRequest)
		return
	}
	dir = filepath.Clean(dir)
	ents, err := os.ReadDir(dir)
	if err != nil {
		http.Error(w, err.Error(), http.StatusNotFound)
		return
	}
	out := map[string]any{"dir": dir, "roots": places(), "dirs": []string{}, "files": []entry{}}
	if p := filepath.Dir(dir); p != dir {
		out["parent"] = p
	}
	find := strings.TrimSpace(r.URL.Query().Get("find"))
	var dirs []string
	var files []entry
	if find != "" { // a search of the folder and its subfolders
		start := time.Now()
		base := strings.Count(dir, string(filepath.Separator))
		filepath.WalkDir(dir, func(p string, d fs.DirEntry, err error) error {
			if err != nil {
				return nil
			}
			if d.IsDir() {
				if p != dir && (hidden(d.Name()) || strings.Count(p, string(filepath.Separator))-base > 8) {
					return filepath.SkipDir
				}
				if len(files) >= 2000 || time.Since(start) > 8*time.Second {
					return filepath.SkipAll
				}
				return nil
			}
			rel, _ := filepath.Rel(dir, p)
			if hidden(d.Name()) || !wildMatch(find, filepath.ToSlash(rel)) {
				return nil
			}
			if fi, err := d.Info(); err == nil {
				at := filepath.Dir(p)
				files = append(files, entry{Name: d.Name(), Size: fi.Size(), Mod: fi.ModTime().Unix(), Path: rel, Dir: &at})
			}
			return nil
		})
		if len(files) >= 2000 || time.Since(start) > 8*time.Second {
			out["note"] = "The search stopped early (a big folder): look in a smaller one."
		}
	} else {
		for _, e := range ents {
			if hidden(e.Name()) {
				continue
			}
			if e.IsDir() || e.Type()&fs.ModeSymlink != 0 && isDir(filepath.Join(dir, e.Name())) {
				dirs = append(dirs, e.Name())
				continue
			}
			if fi, err := e.Info(); err == nil && fi.Mode().IsRegular() {
				files = append(files, entry{Name: e.Name(), Size: fi.Size(), Mod: fi.ModTime().Unix()})
			}
		}
		sort.Strings(dirs)
		a.mu.Lock()
		a.settings.LastDir = dir
		a.mu.Unlock()
	}
	if dirs != nil {
		out["dirs"] = dirs
	}
	if files != nil {
		out["files"] = files
	}
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	json.NewEncoder(w).Encode(out)
}

func isDir(p string) bool { fi, err := os.Stat(p); return err == nil && fi.IsDir() }

// wildMatch: * and ? wildcards (the whole name), else a part of the name;
// upper or lower case alike.
func wildMatch(pat, name string) bool {
	pat, name = strings.ToUpper(pat), strings.ToUpper(name)
	if strings.ContainsAny(pat, "*?") {
		if ok, _ := filepath.Match(pat, name); ok {
			return true
		}
		ok, _ := filepath.Match(pat, strings.ToUpper(filepath.Base(filepath.FromSlash(name))))
		return ok
	}
	return strings.Contains(name, pat)
}

var saveExt = map[string]bool{"ans": true, "ansi": true, "asc": true, "msg": true, "avt": true, "an1": true}

func (a *app) write(w http.ResponseWriter, r *http.Request) {
	dir, name := r.FormValue("dir"), strings.TrimSpace(r.FormValue("name"))
	var ext string
	var data []byte
	if strings.HasSuffix(r.URL.Path, "/save") {
		ext = strings.ToLower(r.FormValue("ext"))
		if !saveExt[ext] && !(strings.HasPrefix(ext, "ansi") && len(ext) == 5 && ext[4] >= '1' && ext[4] <= '9') {
			http.Error(w, "unknown kind of file: ."+ext, http.StatusBadRequest)
			return
		}
		b, err := base64.StdEncoding.DecodeString(r.FormValue("data"))
		if err != nil {
			http.Error(w, "bad data", http.StatusBadRequest)
			return
		}
		data = b
	} else { // a picture (the drawing as PNG, or a file) -> sixel
		ext = "sixel"
		var pic []byte
		if f, _, err := r.FormFile("picture"); err == nil {
			var bb bytes.Buffer
			bb.ReadFrom(f)
			f.Close()
			pic = bb.Bytes()
		} else {
			d := r.FormValue("png")
			if i := strings.IndexByte(d, ','); i >= 0 {
				d = d[i+1:]
			}
			pic, _ = base64.StdEncoding.DecodeString(d)
		}
		img, err := sixel.Decode(bytes.NewReader(pic))
		if err != nil {
			http.Error(w, "That isn't a PNG, GIF or JPEG picture.", http.StatusBadRequest)
			return
		}
		if r.FormValue("full") == "" { // the BBS's size (full: as drawn, up to a limit)
			img = sixel.Scale(img, a.sixW, a.sixH)
		} else {
			img = sixel.Scale(img, 4096, 16384)
		}
		var out bytes.Buffer
		if err := sixel.Encode(&out, img); err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		data = out.Bytes()
	}
	// the extension in the case of the name (MAIN.ANS, main.ans)
	e := ext
	if strings.ToUpper(name) == name {
		e = strings.ToUpper(ext)
	}
	p, err := a.path(dir, name+"."+e)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	// a file there in another case is the same one (Windows)
	if ents, err := os.ReadDir(filepath.Dir(p)); err == nil {
		for _, en := range ents {
			if strings.EqualFold(en.Name(), filepath.Base(p)) {
				p = filepath.Join(filepath.Dir(p), en.Name())
			}
		}
	}
	tmp := p + ".godrawr-tmp"
	if err := os.WriteFile(tmp, data, 0o644); err != nil {
		http.Error(w, "Not saved: "+err.Error(), http.StatusInternalServerError)
		return
	}
	if err := os.Rename(tmp, p); err != nil {
		os.Remove(tmp)
		http.Error(w, "Not saved: "+err.Error(), http.StatusInternalServerError)
		return
	}
	a.mu.Lock()
	a.settings.LastDir = filepath.Dir(p)
	a.mu.Unlock()
	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	fmt.Fprintf(w, "Saved %s (%d bytes).", p, len(data))
}
