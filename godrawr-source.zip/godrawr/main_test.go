package main

import (
	"encoding/base64"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestAPI(t *testing.T) {
	dir := t.TempDir()
	os.MkdirAll(filepath.Join(dir, "sub"), 0o755)
	os.WriteFile(filepath.Join(dir, "MAIN.ANS"), []byte("\x1b[0mHI"), 0o644)
	os.WriteFile(filepath.Join(dir, "sub", "deep.ans"), []byte("x"), 0o644)
	os.WriteFile(filepath.Join(dir, ".hidden"), []byte("x"), 0o644)
	a := &app{token: "tok", sixW: 640, sixH: 400}
	h := a.routes()
	do := func(method, path string, form url.Values) *httptest.ResponseRecorder {
		var r *http.Request
		if form != nil {
			r = httptest.NewRequest(method, path, strings.NewReader(form.Encode()))
			r.Header.Set("Content-Type", "application/x-www-form-urlencoded")
		} else {
			r = httptest.NewRequest(method, path, nil)
		}
		r.Host = "127.0.0.1:1234"
		w := httptest.NewRecorder()
		h.ServeHTTP(w, r)
		return w
	}
	// the token, and only this computer's own name
	if w := do("GET", "/api/list?dir="+url.QueryEscape(dir), nil); w.Code != 403 {
		t.Fatal("no token", w.Code)
	}
	r := httptest.NewRequest("GET", "/?t=tok", nil)
	r.Host = "evil.example:80"
	w := httptest.NewRecorder()
	h.ServeHTTP(w, r)
	if w.Code != 403 {
		t.Fatal("rebinding", w.Code)
	}
	if w := do("GET", "/?t=tok", nil); w.Code != 200 || !strings.Contains(w.Body.String(), `data-mode="app"`) {
		t.Fatal("page", w.Code)
	}
	// a folder
	w = do("GET", "/api/list?token=tok&dir="+url.QueryEscape(dir), nil)
	var l struct {
		Dir    string
		Parent string
		Dirs   []string
		Files  []entry
	}
	json.Unmarshal(w.Body.Bytes(), &l)
	if l.Dir != dir || l.Parent != filepath.Dir(dir) || len(l.Dirs) != 1 || len(l.Files) != 1 || l.Files[0].Name != "MAIN.ANS" {
		t.Fatalf("%s", w.Body)
	}
	// a search of the subfolders
	w = do("GET", "/api/list?token=tok&find=*.ans&dir="+url.QueryEscape(dir), nil)
	json.Unmarshal(w.Body.Bytes(), &l)
	if len(l.Files) != 2 {
		t.Fatalf("%s", w.Body)
	}
	// read, save, a bad name
	if w := do("GET", "/api/file?token=tok&dir="+url.QueryEscape(dir)+"&name=MAIN.ANS", nil); w.Body.String() != "\x1b[0mHI" {
		t.Fatal("read")
	}
	if w := do("GET", "/api/file?token=tok&dir="+url.QueryEscape(dir)+"&name=../x", nil); w.Code != 400 {
		t.Fatal("../x", w.Code)
	}
	w = do("POST", "/api/save", url.Values{"csrf": {"tok"}, "dir": {dir}, "name": {"NEW"}, "ext": {"ansi3"}, "data": {base64.StdEncoding.EncodeToString([]byte("abc"))}})
	if b, _ := os.ReadFile(filepath.Join(dir, "NEW.ANSI3")); string(b) != "abc" || w.Code != 200 {
		t.Fatal("save", w.Code, w.Body)
	}
	w = do("POST", "/api/save", url.Values{"csrf": {"tok"}, "dir": {dir}, "name": {"x"}, "ext": {"exe"}, "data": {""}})
	if w.Code != 400 {
		t.Fatal(".exe saved")
	}
	w = do("POST", "/api/save", url.Values{"csrf": {"bad"}, "dir": {dir}, "name": {"y"}, "ext": {"ans"}, "data": {""}})
	if w.Code != 403 {
		t.Fatal("no token, saved")
	}
}

func TestWildMatch(t *testing.T) {
	for _, c := range []struct {
		pat, name string
		ok        bool
	}{{"main", "MAIN.ANS", true}, {"*.ans", "sub/x.ANS", true}, {"m?in*", "MAIN.ANS", true}, {"zz", "MAIN.ANS", false}} {
		if wildMatch(c.pat, c.name) != c.ok {
			t.Fatal(c)
		}
	}
}
