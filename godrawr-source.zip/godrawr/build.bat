@echo off
rem Build godrawr.exe (Go 1.21+ from https://go.dev/dl/)
go build -trimpath -ldflags "-s -w -H windowsgui" -o godrawr.exe . || goto :err
echo Done: godrawr.exe
goto :eof
:err
echo Build failed.
exit /b 1
